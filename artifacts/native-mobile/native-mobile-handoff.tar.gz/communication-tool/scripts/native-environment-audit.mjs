import {existsSync, mkdirSync, writeFileSync} from 'node:fs';
import {execFileSync, spawnSync} from 'node:child_process';
import {join, resolve} from 'node:path';
import {runtimeFiles} from './runtime-files.mjs';
import {adbPath, jdkRoot, sdkRoot, toolchainEnv} from './android-toolchain.mjs';

const root = resolve(new URL('..', import.meta.url).pathname);
const output = resolve(root, process.argv.find(value => value.startsWith('--output='))?.slice(9) || 'ai-evaluation/results/native-environment-readiness.json');
const command = name => spawnSync('sh', ['-c', `command -v ${name}`], {encoding:'utf8'}).status === 0;
const check = (name, passed, evidence) => ({name, passed:Boolean(passed), evidence});
const runAdb = args => {
  try { return {ok:true, stdout:execFileSync(adbPath, args, {encoding:'utf8', env:toolchainEnv(), timeout:10000})}; }
  catch (error) { return {ok:false, stdout:error.stdout?.toString() || '', error:error.message}; }
};
const deviceResult = existsSync(adbPath) ? runAdb(['devices']) : {ok:false, stdout:''};
const devices = deviceResult.stdout.split(/\r?\n/).filter(line => /\tdevice$/.test(line)).map(line => line.split('\t')[0]);
const emulatorPath = sdkRoot ? join(sdkRoot, 'emulator', process.platform === 'win32' ? 'emulator.exe' : 'emulator') : null;
const avds = emulatorPath && existsSync(emulatorPath) ? spawnSync(emulatorPath, ['-list-avds'], {encoding:'utf8', env:toolchainEnv()}).stdout.trim().split(/\r?\n/).filter(Boolean) : [];
let kvm = false;
try { kvm = existsSync('/dev/kvm') && process.getuid?.() !== undefined && spawnSync('test', ['-r', '/dev/kvm']).status === 0 && spawnSync('test', ['-w', '/dev/kvm']).status === 0; } catch {}
const iosRuntimeMismatches = runtimeFiles.filter(file => {
  const source = resolve(root, file); const target = resolve(root, 'ios/App/App/public', file);
  if (!existsSync(source) || !existsSync(target)) return true;
  return spawnSync('cmp', ['-s', source, target]).status !== 0;
});
const checks = [
  check('Android SDK and JDK', Boolean(sdkRoot && jdkRoot), {sdkRoot, jdkRoot}),
  check('ADB executable', existsSync(adbPath), adbPath),
  check('Android emulator binary', Boolean(emulatorPath && existsSync(emulatorPath)), emulatorPath),
  check('Android AVD exists', avds.includes(process.env.PHRASE_STUDIO_AVD || 'PhraseStudio_API_34'), avds),
  check('KVM acceleration available', kvm, 'Software emulation remains an explicit fallback.'),
  check('Authorized Android target', devices.length === 1, devices),
  check('iOS project shell exists', existsSync(resolve(root, 'ios/App/App.xcodeproj/project.pbxproj')), 'ios/App/App.xcodeproj/project.pbxproj'),
  check('iOS runtime copy matches source', iosRuntimeMismatches.length === 0, {requiredFiles:runtimeFiles.length, mismatched:iosRuntimeMismatches}),
  check('Xcode available', command('xcodebuild'), command('xcodebuild') ? 'xcodebuild' : 'missing'),
  check('CocoaPods available', command('pod'), command('pod') ? 'pod' : 'missing')
];
const androidToolchainReady = checks.slice(0, 4).every(item => item.passed);
const report = {
  schemaVersion:1,
  auditType:'native-environment-readiness',
  generatedAt:new Date().toISOString(),
  fictionalOnly:true,
  passed:checks.every(item => item.passed),
  staticSourceReady:checks[6].passed && checks[7].passed,
  androidToolchainReady,
  androidTargetReady:checks[5].passed,
  iosToolchainReady:checks[8].passed && checks[9].passed,
  checks,
  nextAction:checks[5].passed ? 'Run the Android smoke and complete journey on the dedicated target.' : 'Provide one authorized Android target or a KVM-enabled emulator; then rerun this audit before installing the APK.',
  limitations:['This report describes environment readiness only.', 'It does not prove native UI behavior, accessibility benefit, usefulness, or iOS execution.']
};
mkdirSync(resolve(output, '..'), {recursive:true});
writeFileSync(output, `${JSON.stringify(report, null, 2)}\n`);
console.log(JSON.stringify({...report, output:output.replace(`${root}/`, '')}, null, 2));
if (!report.passed) process.exitCode = 1;
