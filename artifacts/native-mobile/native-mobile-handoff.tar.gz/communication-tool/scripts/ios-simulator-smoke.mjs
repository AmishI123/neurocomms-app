import {existsSync, mkdirSync, writeFileSync} from 'node:fs';
import {execFileSync} from 'node:child_process';
import {resolve} from 'node:path';

const root = resolve(new URL('..', import.meta.url).pathname);
const reportPath = resolve(root, process.env.PHRASE_STUDIO_IOS_SMOKE_REPORT || 'ai-evaluation/results/ios-simulator-smoke.json');
const bundleId = process.env.PHRASE_STUDIO_IOS_BUNDLE_ID || 'org.phrasestudio.app';
const appPath = resolve(root, process.env.PHRASE_STUDIO_IOS_APP_PATH || 'ios/build/Build/Products/Debug-iphonesimulator/App.app');
const startedAt = new Date().toISOString();
const writeReport = report => { mkdirSync(resolve(reportPath, '..'), {recursive:true}); writeFileSync(reportPath, `${JSON.stringify(report, null, 2)}\n`); };
const command = (args, timeout = 30000) => execFileSync('xcrun', args, {encoding:'utf8', timeout}).trim();
const fail = (errorCode, error, nextAction) => { const report = {schemaVersion:1, auditType:'ios-simulator-smoke', startedAt, completedAt:new Date().toISOString(), passed:false, decision:'no-go-before-journey', bundleId, appPath, errorCode, error:String(error), installed:false, launched:false, nativeJourneyVerified:false, nextAction, limitation:'This report proves only bounded simulator smoke; it does not establish the complete iOS journey, accessibility acceptance, usefulness, or human review.'}; writeReport(report); console.error(JSON.stringify(report, null, 2)); process.exitCode = 1; };
if (!existsSync(appPath)) { fail('ios-app-missing', `iOS simulator app is missing at ${appPath}.`, 'Build the unsigned simulator app before running this smoke.'); process.exit(); }
try {
  const devices = JSON.parse(command(['simctl', 'list', 'devices', 'available', '--json']));
  const device = Object.values(devices.devices || {}).flat().find(item => item.isAvailable && /iPhone/.test(item.name));
  if (!device) { fail('ios-simulator-missing', 'No available iPhone simulator was found.', 'Run this job on macOS with an available iPhone simulator runtime.'); process.exit(); }
  if (device.state !== 'Booted') command(['simctl', 'boot', device.udid], 60000);
  command(['simctl', 'bootstatus', device.udid, '-b'], 180000);
  command(['simctl', 'install', device.udid, appPath], 120000);
  command(['simctl', 'launch', device.udid, bundleId]);
  const report = {schemaVersion:1, auditType:'ios-simulator-smoke', startedAt, completedAt:new Date().toISOString(), passed:true, decision:'simulator-smoke-pass-only', bundleId, appPath, device:{name:device.name, udid:device.udid, runtime:device.runtime, state:'Booted'}, installed:true, launched:true, nativeJourneyVerified:false, notTested:['complete iOS journey','offline behavior','persistence across update','keyboard and safe-area behavior','accessibility','human usefulness or accessibility benefit'], limitation:'This report covers simulator boot, installation, and launch only; it is not iOS native acceptance.'};
  writeReport(report); console.log(JSON.stringify(report, null, 2));
} catch (error) { fail('ios-simulator-smoke-failed', error.message, 'Inspect the macOS simulator and rerun the bounded smoke before attempting the full journey.'); }
