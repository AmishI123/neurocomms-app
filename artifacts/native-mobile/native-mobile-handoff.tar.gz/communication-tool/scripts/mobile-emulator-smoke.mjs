import {accessSync, constants, existsSync, mkdirSync, writeFileSync} from 'node:fs';
import {execFileSync, spawn} from 'node:child_process';
import {join, resolve} from 'node:path';
import {sdkRoot, adbPath, toolchainEnv} from './android-toolchain.mjs';
import {waitForAndroidBoot} from './android-boot-wait.mjs';

const avdName = process.env.PHRASE_STUDIO_AVD || 'PhraseStudio_API_34';
const bootSeconds = Math.max(30, Number(process.env.PHRASE_STUDIO_EMULATOR_BOOT_SECONDS) || 180);
const snapshot = process.env.PHRASE_STUDIO_EMULATOR_SNAPSHOT || '';
const reportPath = resolve(new URL('..', import.meta.url).pathname, process.env.PHRASE_STUDIO_EMULATOR_SMOKE_REPORT || 'ai-evaluation/results/android-emulator-smoke.json');
const startedAt = new Date().toISOString();
const writeReport = report => { mkdirSync(resolve(reportPath, '..'), {recursive:true}); writeFileSync(reportPath, `${JSON.stringify(report, null, 2)}\n`); };
const fail = message => { console.error(`Android emulator smoke failed: ${message}`); process.exitCode = 1; };
if (!sdkRoot) { fail('Android SDK was not found.'); process.exit(); }
let acceleration = [];
if (process.platform === 'linux') {
  try { accessSync('/dev/kvm', constants.R_OK | constants.W_OK); }
  catch { if (process.env.PHRASE_STUDIO_ALLOW_SOFTWARE_EMULATOR !== '1') { fail('KVM acceleration is unavailable. Run `sudo usermod -aG kvm "$USER"`, then log out and back in, or set PHRASE_STUDIO_ALLOW_SOFTWARE_EMULATOR=1 for a slower software-emulated run.'); process.exit(); } acceleration = ['-accel', 'off']; console.warn('KVM unavailable; using slower software emulation because PHRASE_STUDIO_ALLOW_SOFTWARE_EMULATOR=1.'); }
}
const emulator = join(sdkRoot, 'emulator', process.platform === 'win32' ? 'emulator.exe' : 'emulator');
if (!existsSync(emulator)) { fail(`emulator binary is missing at ${emulator}.`); process.exit(); }
const env = {...toolchainEnv()};
const port = Number(process.env.PHRASE_STUDIO_EMULATOR_PORT || 5580);
if (!Number.isInteger(port) || port < 5554 || port > 5682 || port % 2) { fail('emulator port must be an even integer from 5554 to 5682.'); process.exit(); }
const serial = `emulator-${port}`;
const existing = execFileSync(adbPath, ['devices'], {encoding:'utf8', env, timeout:10000});
if (existing.split(/\r?\n/).some(line => line.startsWith(serial+'\t'))) { fail('the selected emulator test target is already in use.'); process.exit(); }
const snapshotArgs = snapshot ? ['-snapshot', snapshot, '-no-snapshot-save'] : ['-no-snapshot'];
const child = spawn(emulator, ['-avd', avdName, '-port', String(port), '-read-only', ...acceleration, '-gpu', 'swiftshader_indirect', '-no-audio', '-no-boot-anim', '-no-window', ...snapshotArgs, '-no-metrics'], {stdio:'inherit', env});
let stopped = false;
let launchError;
child.on('error', error => { launchError = error; });
const stop = () => {
  if (stopped) return;
  stopped = true;
  child.kill('SIGTERM');
};
process.on('SIGINT', () => { stop(); });
process.on('SIGTERM', () => { stop(); });
try {
  await waitForAndroidBoot({serial, timeoutMs:bootSeconds * 1000,
    stopped:() => stopped || Boolean(launchError) || child.exitCode !== null || child.signalCode !== null,
    runAdb:(args, timeout) => execFileSync(adbPath, args, {encoding:'utf8', env, timeout}),
    progress:message => console.log(`Android boot: ${message}`)});
  const smoke = spawn(process.execPath, ['scripts/mobile-device-smoke.mjs', `--serial=${serial}`], {stdio:'inherit', env:{...env, ADB_PATH:adbPath}});
  await new Promise((resolve, reject) => { smoke.on('error', reject); smoke.on('exit', code => code === 0 ? resolve() : reject(new Error(`device smoke exited (${code ?? 'unknown'}).`))); });
  writeReport({schemaVersion:1, auditType:'android-emulator-smoke', startedAt, completedAt:new Date().toISOString(), passed:true, decision:'smoke-pass-only', avd:avdName, serial, bootSeconds, snapshot:snapshot || null, errorCode:null, apkInstallationAttempted:true, nativeJourneyVerified:false, limitation:'This smoke report covers emulator boot and the activity/intent smoke only; it does not establish the complete native journey or accessibility acceptance.'});
  console.log(JSON.stringify({passed:true,avd:avdName}, null, 2));
} catch (error) {
  const message = error.message;
  writeReport({schemaVersion:1, auditType:'android-emulator-smoke', startedAt, completedAt:new Date().toISOString(), passed:false, decision:'no-go-before-installation', avd:avdName, serial, bootSeconds, snapshot:snapshot || null, errorCode:/booting within/i.test(message) ? 'emulator-boot-timeout' : 'emulator-start-failed', error:message, apkInstallationAttempted:false, nativeJourneyVerified:false, limitation:'The software emulator did not become an authorized Android target; no APK installation or UI result is claimed.'});
  fail(message);
} finally {
  stop();
}
