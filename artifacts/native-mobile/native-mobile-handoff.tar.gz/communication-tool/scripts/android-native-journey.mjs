import {existsSync, mkdirSync, writeFileSync} from 'node:fs';
import {execFileSync} from 'node:child_process';
import {resolve} from 'node:path';
import {createHash} from 'node:crypto';
import {readFileSync} from 'node:fs';
import {adbPath, toolchainEnv} from './android-toolchain.mjs';
import {restartAndroidView} from './android-view-restart.mjs';

// Explicit opt-in: installs and force-stops this app on a dedicated target only.
const serial = process.argv.find(arg => arg.startsWith('--serial='))?.slice(9);
if (!serial || !process.argv.includes('--dedicated-test-target')) {
  console.error('Requires --serial=<target> --dedicated-test-target. Use only a dedicated fictional-data installation.');
  process.exit(1);
}
const root = resolve(new URL('..', import.meta.url).pathname);
const apk = resolve(root, 'android/app/build/outputs/apk/debug/app-debug.apk');
const pkg = 'org.phrasestudio.app';
class JourneyError extends Error {
  constructor(code, message) { super(message); this.code = code; }
}
const env = toolchainEnv();
const adb = (args, timeout=15000) => execFileSync(adbPath, args, {encoding:'utf8',env,timeout});
const target = (args, timeout) => adb(['-s',serial,...args],timeout);
let device;
const completed = [];
const reportPath = resolve(root, process.env.PHRASE_STUDIO_ANDROID_JOURNEY_REPORT || 'ai-evaluation/results/android-native-journey.json');
const startedAt = new Date().toISOString();
const writeReport = report => { mkdirSync(resolve(reportPath, '..'), {recursive:true}); writeFileSync(reportPath, `${JSON.stringify(report, null, 2)}\n`); };
try {
  if (!existsSync(apk)) throw Error('Build the debug APK first.');
  const deviceLines = adb(['devices']).split(/\r?\n/).filter(line => line && !/^List of devices attached/.test(line));
  const devices = deviceLines.filter(line => /\tdevice$/.test(line)).map(line => line.split('\t')[0]);
  // Playwright enumerates WebViews for its connected devices. Avoid inspecting
  // unrelated devices by requiring only this dedicated target to be connected.
  if (devices.length === 0) throw new JourneyError('no-authorized-target', 'No authorized Android device or emulator is connected.');
  if (devices.length !== 1 || devices[0] !== serial) throw new JourneyError('dedicated-target-boundary', 'Connect only the named authorized dedicated target.');
  if (target(['shell','getprop','sys.boot_completed']).trim() !== '1') throw new JourneyError('target-not-booted', 'Android has not completed boot.');
  execFileSync(process.execPath,['scripts/mobile-bundle-audit.mjs',`--apk=${apk}`],{cwd:root,env,timeout:60000,stdio:'pipe'});
  execFileSync(process.execPath,['scripts/android-permission-audit.mjs',`--apk=${apk}`],{cwd:root,env,timeout:30000,stdio:'pipe'});
  target(['install','-r',apk],120000);
  target(['shell','am','start','-W','-n',pkg+'/.MainActivity'],30000);
  const {_android} = await import('playwright');
  const devicesForAutomation = await _android.devices({omitDriverInstall:true});
  device = devicesForAutomation.find(item => item.serial() === serial);
  if (!device) throw Error('The dedicated target is unavailable to WebView automation.');
  device.setDefaultTimeout(30000);
  async function attach() {
    const view = await device.webView({pkg},{timeout:30000});
    const page = await view.page();
    page.setDefaultTimeout(30000);
    await page.locator('#home-add').waitFor({state:'attached'});
    return {page,view};
  }
  let {page,view} = await attach();
  // Do not overwrite a tester's pre-existing work. No clear-data/uninstall path.
  const hasWork = await page.evaluate(() => ['phrase-studio-study-bridge-v1','phrase-studio-study-review-v1',
    'phrase-studio-draft-v1','phrase-studio-library-v1'].some(key => localStorage.getItem(key) !== null));
  if (hasWork) throw Error('Existing work detected. Use a fresh dedicated test installation; no data was cleared.');
  completed.push('installed-and-attached-native-webview');
  await page.locator('[data-route="home"]').click();
  await page.locator('#home-add').click();
  await page.locator('#study-bridge-input').fill('Read the fictional native beta rubric.\nWrite a fictional outline.');
  const studyExtractionStarted = await page.evaluate(() => performance.now());
  await page.locator('#study-bridge-extract').click();
  await page.locator('#study-bridge-confirm').click();
  await page.waitForFunction(() => document.getElementById('study-bridge-status').textContent.includes('Plan confirmed and saved'));
  const studyExtractionElapsedMs = await page.evaluate(started => Math.round(performance.now() - started), studyExtractionStarted);
  const note = 'Fictional native restart: rubric read; outline next.';
  await page.locator('#study-work-note').fill(note);
  await page.locator('#study-work-pause').click();
  await page.locator('#experience-home').waitFor({state:'visible'});
  const saved = await page.evaluate(() => localStorage.getItem('phrase-studio-study-bridge-v1'));
  if (!saved || JSON.parse(saved).tasks.length !== 2) throw Error('Expected confirmed two-step fixture.');
  completed.push('review-confirm-save-and-pause');
  ({page,view} = await restartAndroidView({page,view,
    stop:() => target(['shell','am','force-stop',pkg]),
    launch:() => target(['shell','am','start','-W','-n',pkg+'/.MainActivity'],30000),attach}));
  await page.locator('[data-route="home"]').click();
  await page.locator('#home-continue').click();
  if (await page.locator('#study-work-note').inputValue() !== note) throw Error('Restart note was not restored.');
  if (await page.evaluate(() => localStorage.getItem('phrase-studio-study-bridge-v1')) !== saved) throw Error('Confirmed plan changed across native restart.');
  completed.push('native-force-stop-relaunch-retains-confirmed-work');
  await page.locator('#study-all-steps').evaluate(element => { element.open = true; });
  await page.getByRole('button', {name:'Export journey evidence'}).click();
  await page.waitForFunction(() => document.getElementById('study-work-status')?.textContent.includes('Journey evidence exported without source text'));
  const exportedJourney = await page.evaluate(() => JSON.parse(localStorage.getItem('phrase-studio-study-bridge-journey-v1') || 'null'));
  if (exportedJourney?.state !== 'exported' || exportedJourney?.export?.redacted !== true || exportedJourney?.export?.rawSourceIncluded !== false) throw Error('Journey export did not persist the source-free boundary.');
  if (JSON.stringify(exportedJourney).includes('Read the fictional native beta rubric')) throw Error('Journey metadata retained fictional source text.');
  completed.push('redacted-journey-export-boundary');
  const report = {schemaVersion:1, auditType:'android-native-journey', startedAt, completedAt:new Date().toISOString(), passed:true, scope:'native-confirmed-work-restart-and-redacted-export-slice', serial,
    model:device.model(),androidVersion:target(['shell','getprop','ro.build.version.release']).trim(),
    apkSha256:createHash('sha256').update(readFileSync(apk)).digest('hex'),completed,
    studyBridge:{extractionElapsedMs:studyExtractionElapsedMs,fixture:'fictional two-line text',timingScope:'WebView fill, extraction, confirmation, and save'},
    notTested:['native-file-picker','offline-device-network','keyboard-and-safe-area','share-reception',
      'redacted-plan-file-download','in-place-version-upgrade','accessibility','iOS'],
    dataDisposition:'Fictional fixture remains on the dedicated test installation; nothing erased.'};
  writeReport(report);
  console.log(JSON.stringify({...report, reportPath},null,2));
} catch (error) {
  const report = {schemaVersion:1, auditType:'android-native-journey', startedAt, completedAt:new Date().toISOString(), passed:false,
    scope:'native-confirmed-work-restart-slice', serial, completed, errorCode:error.code || 'native-journey-failed',
    error: error.message, uiContentVerified:false, nativeJourneyVerified:false,
    limitation:'A failed or incomplete run is not evidence of native acceptance.'};
  writeReport(report);
  console.error(JSON.stringify({...report, reportPath},null,2));
  process.exitCode=1;
} finally { if (device) await device.close(); }
