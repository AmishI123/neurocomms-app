const {test}=require('node:test');
const assert=require('node:assert/strict');
const {spawnSync}=require('node:child_process');
const path=require('node:path');
const fs=require('node:fs');
test('native journey records WebView Study Bridge timing without claiming device evidence',()=>{
  const source=fs.readFileSync(path.resolve(__dirname,'../scripts/android-native-journey.mjs'),'utf8');
  assert.match(source,/studyExtractionElapsedMs/);
  assert.match(source,/timingScope:'WebView fill, extraction, confirmation, and save'/);
  assert.match(source,/redacted-journey-export-boundary/);
  assert.match(source,/rawSourceIncluded !== false/);
});
for(const args of [[],['--serial=fictional-target'],['--dedicated-test-target']]) {
  test('native journey refuses incomplete dedicated-target authorization: '+JSON.stringify(args),()=>{
    const result=spawnSync(process.execPath,['scripts/android-native-journey.mjs',...args],{
      cwd:path.resolve(__dirname,'..'),encoding:'utf8',timeout:5000,env:{...process.env,ADB_PATH:'/nonexistent/adb-must-not-run'}});
    assert.equal(result.status,1);assert.match(result.stderr,/Requires --serial/);
    assert.doesNotMatch(result.stderr,/ENOENT/);assert.equal(result.stdout,'');
  });
}
