# Installable, dependable native mobile beta

Deferred: native test environments are unavailable. The user explicitly redirected
active work to `web-workspace-goal.md`. The native gates below remain unfulfilled;
web-first completion will not imply native-beta acceptance.

## Goal and completion boundary

Deliver and verify the shared app inside actual Android and iOS installations:
install → first launch → import fictional instructions → review and confirm → work
offline → background/terminate → reopen and resume → revise → export → update
without losing confirmed work. Browser tests and copied native assets alone do
not complete this goal. This phase requires native execution evidence on both
platforms; unavailable environments remain incomplete, not accepted by substitution.

## Work packages

1. Establish exact test targets, build identities, native prerequisites and evidence
   locations. Distinguish build readiness, launch smoke and complete journey evidence.
2. Exercise keyboards, scrolling, safe areas, Android Back, file selection, share
   reception, permission denial and selected accessibility interactions. Fix observed
   platform failures and rerun the affected journey.
3. Verify saved/unsaved behavior across backgrounding, force-stop, offline restart,
   storage failures and an in-place update with a retained real installation.
   Do not relabel a compatible browser-cache fixture as native upgrade evidence.
4. Produce installable beta builds, clear first-use instructions, data deletion and
   recovery paths, install/update guidance and a rollback/recovery checklist.
   Signing/distribution credentials remain owner-controlled; no uploads or public
   distribution are authorized by this goal.
5. Record device/OS/build, executed actions, observed outcomes and failures. Package
   the evidence with exact hashes and a platform-by-platform release decision.

## Gates

- Dedicated authorized targets and fictional data only. Do not erase an existing
  personal installation, change host privileges, or modify another app's data.
- Assert visible app state and durable state, not just successful activity launch.
- Keep acceptance criteria fixed across platforms; report unsupported capabilities.
- Never invent a device, native result, reviewer, participant or usefulness claim.
- Any destructive app-data check must be limited to a dedicated test installation.
- Human feedback is not a dependency for engineering verification; usability and
  clinical/academic outcomes remain unproven.

## Starting evidence

The completed shared-frontend phase has 182 passing tests, cache version 18 and a
matching 25-file Android debug APK. See `cross-platform-design-acceptance.md`.
The current doctor reports an Android toolchain but no authorized target; Xcode
and CocoaPods are absent. AVD `PhraseStudio_API_34` exists. The emulator's own
acceleration probe reports insufficient permission for `/dev/kvm`. No privilege
change is authorized. Earlier software emulation timed out at 180 seconds.

`mobile-device-smoke.mjs` installs, launches and sends two Android intents. Its
current success result does not assert received UI content, persistence, keyboard
behavior, offline execution or update retention. These are required new evidence,
not properties inferred from the existing smoke script.

## Immediate next engineering work

Bound emulator boot/command waits, attempt a longer read-only software-emulated
boot if no accelerated target is available, and build an Android journey harness
that checks app state. Keep iOS build/device execution explicitly outstanding until
an authorized macOS/Xcode environment is available. Ask the owner for that access
when local preparation cannot advance it further.

## First implementation checkpoint

`scripts/android-boot-wait.mjs` now separates authorization from completed boot,
uses a monotonic deadline and caps each ADB probe to the remaining budget (maximum
10 seconds). Emulator process exit/signal and launch errors fail the wait. Progress
reports identify authorization, incomplete boot and probe failures. The emulator
smoke runner uses this helper rather than counting nominal two-second iterations.

All five `tests/android-boot-wait.test.cjs` tests pass: exact target, authorized but
unbooted timeout, ADB failure, response after deadline and stopped process. These
are helper tests with simulated time, not native device evidence.

A 600-second read-only software-emulator attempt has started on `emulator-5580`.
The emulator process is live and has initialized its display/network backend; the
target is not yet authorized. This is an in-progress attempt, not a boot or app pass.
The owner has been asked about an authorized macOS/Xcode environment for iOS while
Android work continues. No host group membership or privileges were changed.

## Native journey harness checkpoint

`npm run mobile:android:journey -- --serial=TARGET --dedicated-test-target` now
provides an initial installed-WebView journey: package/source audit, install,
source entry, review/confirmation, saved restart note, native force-stop/relaunch
and exact saved-plan retention. It requires a sole dedicated authorized target,
refuses existing saved work and never clears/uninstalls app data. Source text and
saved-plan bytes are compared in memory, not printed in its result.

Three authorization-guard tests pass without invoking ADB. Together with the boot
wait tests, eight tests pass. Syntax and whitespace checks pass. This establishes
guard/helper behavior only; the native harness itself has not executed on a booted
target and may need platform-specific fixes once it can run. Its success scope is
explicitly a restart slice, with all remaining beta gates listed as not tested.

The original launch smoke now has bounded ADB command waits and an explicit
`activity-intent-launch-only` scope; UI content and complete native journey are
marked unverified. The active software emulator is still live, approximately four
minutes into the 600-second boot window; ADB reports `emulator-5580 offline`.
Do not restart it based on this intermediate observation.

## Reconnect and packaged-permission checkpoint

The restart helper now observes both the old page closing and the old WebView
being removed before relaunch. This avoids selecting the stale socket retained
briefly by Android automation. Three lifecycle tests cover delayed removal,
timeout and failed force-stop cleanup; the combined harness tests pass (11 tests).
They remain simulated lifecycle evidence, not a native restart result.

Actual `aapt` inspection of the existing APK found versionCode 1 and five permission
requests, whereas the old source audit exposed only two. Local plugin/merged
manifests confirm the additional boot/wake requests and app-scoped receiver
permission. The new `--apk` permission audit reports all five with declared reasons,
rejects unknown requests or invalid package/output, and explicitly leaves runtime
behavior unverified. Its three tests pass, and auditing the real existing APK passes.
Both future Android builds and the native journey preflight now run this package
gate. No permissions were added to the app by this audit change.

A version-incremented APK pair is still future work; inspection only established
that the current build is versionCode 1. Native install/update retention has not
been tested or inferred from package inspection.

The combined boot, authorization, lifecycle, packaged-permission and product-contract
run passed all 16 tests with zero failures/skips/cancellations. The 600-second
software-emulator attempt then terminated with exit 1: the target never became
authorized or completed boot. The runner shut down its emulator; no app installation
or native journey was reached. This longer attempt does not establish a native pass.
Actual Android execution now requires an authorized device or KVM-enabled target;
iOS still requires an authorized Mac/Xcode environment. Neither is available here.

## Current execution check — 17 September 2026

The current APK and toolchain were checked again. `adb devices -l` returned no
targets, and the real device entry point was run:

```text
Mobile device smoke failed: no authorized Android device or emulator is connected.
exit 1
```

This is the expected fail-closed result. It confirms that no installation or
native journey was attempted on an unknown target; it does not count as a
native pass. The next execution requires one dedicated authorized Android
device/emulator. iOS still requires macOS with Xcode and CocoaPods.

The smoke command now also writes the source-free report
`ai-evaluation/results/mobile-device-smoke.json` (or the path supplied through
`PHRASE_STUDIO_DEVICE_SMOKE_REPORT`). A no-target result records
`errorCode: no-authorized-target`; a successful smoke result records only
install/launch/intent step status and still does not claim the complete native
journey.

The operator-facing [native execution handoff](native-beta-execution-handoff-2026-09-17.html)
contains the current APK hash, exact run order, and evidence limits.

When this Linux host cannot provide an authorized target, the checked-in
`../.github/workflows/native-acceptance.yml` is the reproducible next route. Its
Android job builds the APK, starts a dedicated API 34 emulator, runs the smoke
and native journey commands, and uploads their source-free reports. Its iOS job
runs on macOS, installs the Pods, and builds the simulator app without signing.
Those workflow results must still be inspected for actual device and app
outcomes; the workflow file itself is not native acceptance.

The complete Android journey harness also writes
`ai-evaluation/results/android-native-journey.json` (or the path supplied by
`PHRASE_STUDIO_ANDROID_JOURNEY_REPORT`). It records completed steps on partial
failure and never turns a failed or incomplete run into an acceptance claim.

## Fresh shared mobile acceptance — 17 September 2026

The current checkout passed `npm run mobile:acceptance`:

- 37/37 runtime files match the source bundle;
- source Android permissions contain no unexpected entries;
- the static accessibility gate passed all 11 checks;
- the product contract passed 2/2 tests.

This is shared-bundle and contract evidence. It does not replace execution on
an Android device, an iOS installation, or a human accessibility review.

## Latest software-emulator preflight — 17 September 2026

The existing `PhraseStudio_API_34` AVD was started with the documented
software-emulation override because this host cannot use `/dev/kvm`. It stayed
offline and did not become an authorized target within the bounded boot window;
the APK was not installed. The source-free result is
`ai-evaluation/results/android-emulator-smoke.json` with
`errorCode: emulator-boot-timeout`. This is a recorded environment failure,
not a native product result. The next Android attempt needs a physical device
or a target with usable acceleration.
