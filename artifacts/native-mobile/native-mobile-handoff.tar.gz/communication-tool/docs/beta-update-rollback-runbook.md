# Local beta update, rollback, and cache-recovery runbook

This runbook is for the self-contained local-first beta described in the
[beta goal](next-meaty-goal-local-beta-release.md). It is an operator procedure
and does not authorize public distribution or human testing.

## Before an update

1. Stop active work and export a local backup from the app.
2. Keep the backup on the device or a user-controlled location. Do not send it
   to a provider or commit it to the repository.
3. Record the current release version and confirm that the new artifact came
   from the documented build and hash manifest.
4. Deploy the new artifact atomically: the HTML, JavaScript modules, manifest,
   and service worker must come from the same release directory.

## Normal update

The service worker uses a versioned `phrase-studio-vN` runtime cache. A new
release increments `CACHE` in `sw.js`. On activation, old caches with the
`phrase-studio-` prefix are deleted, while the separate pending-share cache is
retained. The install step precaches the approved runtime and waits for it to
finish before activation.

After deployment, reload once with network access, confirm the displayed
release/build information, then perform the fictional smoke path: open the
app, create a plan, pause it, reload, and resume it. Turn network access off
and repeat the read-only and resume checks. If any step fails, stop and roll
back; do not ask a user to clear data as the first response.

## Rollback after a bad release

1. Stop serving the bad artifact and restore the previous known-good artifact
   atomically.
2. Keep the current local backup and do not erase app data.
3. Reload the app. The restored service worker should install the prior cache
   version and remove the bad version during activation.
4. Verify that existing local state is present and that the fictional pause,
   reload, and resume path works offline.
5. If the old bundle reports an incompatible schema, preserve the backup,
   capture only the displayed error code, and do not attempt repeated restores.

## Stale or failed service-worker recovery

If the page is stale, close all app tabs, reopen the known-good artifact, and
allow one update/reload cycle. If that does not recover the runtime, export a
backup if the app is still usable, then use the browser's site-data controls
for this app origin to clear only its local data and caches. Restore the
validated backup and verify the fictional smoke path. Clearing site data is a
last-resort recovery action because it can remove state not present in the
backup.

## Failure boundaries

- A malformed or incompatible backup must be rejected before replacing the
  current valid state.
- A failed update must not trigger provider calls, automatic messages, or
  silent data deletion.
- Support notes contain release version, error code, and step reached only;
  they must not contain source text, phrases, filenames, credentials, or
  provider URLs.
- This procedure has not established browser/device compatibility beyond the
  environments exercised by the release audit. Human distribution remains a
  separate approval decision.

## Exercise record

The current browser exercise records old-cache deletion, preserved pending-share
state, rejection of a malformed backup without replacing valid state, and a
successful bad-release rollback with preserved local state. The release
candidate still requires the mobile/environment gates and any deviations to be
recorded. A passing static audit alone is evidence of contract coverage, not
evidence of human usability or compatibility beyond the exercised browser.

## Current mobile environment record

The Android API 34 debug APK and scoped mobile bundle audit pass in the current
workspace. The configured `PhraseStudio_API_34` emulator is present, but this
user cannot access `/dev/kvm`; the documented software-emulation fallback was
attempted with headless/no-snapshot launch flags and a 360-second boot budget,
but ADB remained offline and the emulator did not finish booting. Android
device smoke evidence is therefore not claimed. Repeat
`PHRASE_STUDIO_ALLOW_SOFTWARE_EMULATOR=1 PHRASE_STUDIO_EMULATOR_BOOT_SECONDS=360 npm run mobile:emulator:smoke`
on a host with KVM access or an authorized physical/emulated device before
claiming Android runtime compatibility. The internal beta decision may remain
`beta-ready-with-environment-limits` while this environment limitation is
explicitly carried in release materials.
