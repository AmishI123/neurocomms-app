# Native handoff: current Communication Access Card build

## Result

The current web/mobile source was copied into Capacitor, compiled into Android
debug and unsigned release APKs, and checked for exact runtime contents. The
iOS public web assets were copied from the same current bundle. The repository
also contains a macOS workflow step that builds, installs, and launches the
simulator app before any future full iOS journey work.

This is a build handoff. It is not proof of Android or iOS device behavior,
native accessibility, usefulness, store approval, or participant benefit.

## Android evidence

Both APKs contain the exact current 39-file runtime bundle:

| Artifact | Size | SHA-256 | Status |
|---|---:|---|---|
| `android/app/build/outputs/apk/debug/app-debug.apk` | 5,101,162 bytes | `8d18e4040784add454c06b301e5948969078376b782e47e58c17673023816547` | Debug build |
| `android/app/build/outputs/apk/release/app-release-unsigned.apk` | 4,000,906 bytes | `e67b5f03288066201bd41a536b648d894b35b1a21c3599aa5a4f22b345b7eaa8` | Unsigned release build |

The Android release build completed successfully. The mobile bundle audit and
packaged permission audit passed for both APKs. The release artifact manifest
reports 42 artifacts and no missing required files.

The release signing audit reports `unsigned` and `distributable: false`. No
private signing key was inspected.

## iOS evidence

Capacitor copied the current 39-file web bundle into `ios/App/App/public`.
The files match the source bundle. This host has no Xcode or CocoaPods, so there
is no iOS compilation, simulator run, or device result here. The local bounded
preflight records `ios-app-missing`; the macOS workflow is the execution route.

## Repeatable commands

```bash
PHRASE_STUDIO_ANDROID_HOME=/home/mehta/Android/Sdk \
PHRASE_STUDIO_JAVA_HOME=/home/mehta/Android/jdk \
npm run mobile:build:android

PHRASE_STUDIO_ANDROID_HOME=/home/mehta/Android/Sdk \
PHRASE_STUDIO_JAVA_HOME=/home/mehta/Android/jdk \
npm run mobile:build:android:release

node scripts/release-artifact-manifest.mjs --platform=android \
  --output=ai-evaluation/results/communication-card-native-artifact-manifest.json
```

## Evidence files

- `ai-evaluation/results/communication-card-native-artifact-manifest.json`
- `ai-evaluation/results/communication-card-android-signing-audit.json`
- `ai-evaluation/results/communication-card-cross-surface-audit.json`

## Next required external step

An authorized Android device or working emulator must install the exact APK and
run the card flow. An authorized macOS/Xcode environment must compile and run
the iOS shell. Until then, the native result remains a reproducible package
handoff rather than native acceptance.

## Latest execution attempt — 17 September 2026

The complete Android journey runner was invoked against the named
`emulator-5554` target with dedicated-target protection enabled. It failed
closed with `errorCode: no-authorized-target` because no authorized target was
connected. The report is
`ai-evaluation/results/android-native-journey.json`.

No APK was installed, no app state was changed, and no native acceptance is
claimed. Repeat the same command only after connecting an authorized dedicated
Android device or emulator. iOS remains source-ready only until it is run on
macOS with Xcode and CocoaPods.

## Handoff consistency check

Run `npm run native:handoff-audit` before giving this package to an operator.
The current check passes all nine consistency checks: current Android APK
hash, report links, artifact manifest, 39-file iOS runtime copy, and explicit
Android limitation reports. Its result is
`ai-evaluation/results/native-handoff-audit.json`.

Create the portable, source-free operator package with
`npm run native:handoff-package`. It contains the current debug and unsigned
release APKs, their hashes, the run instructions, and the explicit Android and
iOS limits. The package manifest is
`ai-evaluation/results/native-handoff-package-manifest.json`.

Verify the archive before installation with `npm run native:handoff-verify`.
The verifier extracts the archive into a temporary directory, checks the
archive hash, exact file set, every file hash, and the fictional-data boundary.
