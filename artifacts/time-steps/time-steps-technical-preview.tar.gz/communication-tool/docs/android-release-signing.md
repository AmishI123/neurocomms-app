# Android release signing

The normal Android release build creates an unsigned APK. That is deliberate:
the repository does not contain a private key, and a local build must not invent
or silently use one.

## Sign a release APK

Keep the keystore and passwords in the release owner’s secret store. From
`communication-tool/`, set these environment variables for one command only:

```bash
export PHRASE_STUDIO_ANDROID_KEYSTORE_BASE64='BASE64_KEYSTORE_BYTES'
export PHRASE_STUDIO_ANDROID_KEYSTORE_PASSWORD='STORE_PASSWORD'
export PHRASE_STUDIO_ANDROID_KEY_ALIAS='RELEASE_ALIAS'
export PHRASE_STUDIO_ANDROID_KEY_PASSWORD='KEY_PASSWORD'
npm run mobile:build:android:release
npm run mobile:sign-release
```

The command reads the unsigned APK, copies the decoded keystore to a protected
temporary file, signs a separate output APK, verifies it with `apksigner`,
prints only the output path and SHA-256, and removes the temporary keystore.
It never prints the keystore bytes or passwords. The signed output is:

```text
android/app/build/outputs/apk/release/app-release-signed.apk
```

Then run the existing audit against the signed file:

```bash
npm run mobile:signing-audit -- --apk=android/app/build/outputs/apk/release/app-release-signed.apk
```

The audit must report `signingState: "signed"` and `distributable: true`.

## Failure rules

- Missing credentials stop before any signing attempt.
- The input and output files must be different.
- A missing `apksigner`, invalid keystore, failed signing operation, or failed verification is a failure.
- The current unsigned APK remains the only default build output.
- Do not paste a keystore, password, or private key into source control, logs,
  issue comments, or a chat transcript.

Signing makes an APK technically distributable; it does not prove device
behavior, human usefulness, accessibility benefit, or store approval.

## Optional CI signing

The Android CI job checks for all four secrets without printing their values:

- `PHRASE_STUDIO_ANDROID_KEYSTORE_BASE64`
- `PHRASE_STUDIO_ANDROID_KEYSTORE_PASSWORD`
- `PHRASE_STUDIO_ANDROID_KEY_ALIAS`
- `PHRASE_STUDIO_ANDROID_KEY_PASSWORD`

If any one is missing, CI keeps the unsigned APK and still passes the
engineering gate. If all four are present, CI signs a separate
`app-release-signed.apk`, verifies it, and uploads
`android-signing-report.json`. The private key is never committed or written to
the workspace; only the signer’s temporary protected file is used.
