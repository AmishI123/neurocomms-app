const KEY = 'phrase-studio-time-steps-v1';
const ids = ['appointment','label','preparation','travel','spare','display'];
const el = name => document.getElementById(`time-steps-${name}`);
const values = () => Object.fromEntries(ids.map(name => [name, el(name).value]));
const fill = data => ids.forEach(name => { if (data[name] !== undefined) el(name).value = data[name]; });
const validSaved = data => data && typeof data === 'object' && !Array.isArray(data) && ids.every(name => typeof data[name] === 'string') && (data.display === '12' || data.display === '24') && (!data.appointment || !Number.isNaN(new Date(data.appointment).getTime())) && ['preparation','travel'].every(name => /^\d+$/.test(data[name]) && Number(data[name]) <= 1440) && (!data.spare || (/^\d+$/.test(data.spare) && Number(data.spare) <= 1440));
const escapeHtml = value => String(value).replace(/[&<>"']/g, character => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[character]));
const format = date => date.toLocaleString(undefined, {weekday:'short', month:'short', day:'numeric', year:'numeric', hour:'numeric', minute:'2-digit', hour12:el('display').value === '12'});
function number(name, optional = false) { const raw = el(name).value.trim(); if (!raw && optional) return 0; if (!/^\d+$/.test(raw)) throw Error(`${el(name).previousElementSibling.textContent} must be a whole number of minutes.`); const value = Number(raw); if (value < 0 || value > 1440) throw Error(`${el(name).previousElementSibling.textContent} must be between 0 and 1440 minutes.`); return value; }
function calculate() {
  if (!el('appointment').value) throw Error('Choose an appointment date and time.');
  const appointment = new Date(el('appointment').value); if (Number.isNaN(appointment.getTime())) throw Error('Choose a valid appointment date and time.');
  const preparation = number('preparation'); const travel = number('travel'); const spare = number('spare', true);
  const leave = new Date(appointment.getTime() - (travel + spare) * 60000); const start = new Date(leave.getTime() - preparation * 60000);
  if ([leave, start].some(date => date.getTimezoneOffset() !== appointment.getTimezoneOffset())) throw Error('This version cannot safely calculate across a daylight-saving time change. Try a time that stays within one offset.');
  const label = el('label').value.trim();
  document.getElementById('time-steps-result').innerHTML = `<p class="quiet">${label ? `${escapeHtml(label)} · ` : ''}These times use the minutes you entered.</p><div class="time-steps-cards"><article><small>START PREPARING</small><strong>${format(start)}</strong><span>Begin getting ready.</span></article><article><small>LEAVE</small><strong>${format(leave)}</strong><span>Travel for ${travel} minutes and keep ${spare} minutes spare.</span></article><article><small>APPOINTMENT</small><strong>${format(appointment)}</strong><span>Arrive for the appointment.</span></article></div><p class="time-steps-formula"><strong>Visible calculation:</strong> appointment minus travel (${travel}) minus spare (${spare}) minus preparation (${preparation}) = start preparing.</p>`;
}
function showError(reason) { document.getElementById('time-steps-result').innerHTML = `<p class="time-steps-warning" role="alert">${escapeHtml(reason.message)}</p>`; }
function example() { fill({appointment:'2026-09-18T10:00',label:'Example appointment',preparation:'20',travel:'30',spare:'10',display:'24'}); try { calculate(); document.getElementById('time-steps-status').textContent = 'Example loaded. Change it so it fits you.'; } catch (reason) { showError(reason); } }
function save() { try { calculate(); localStorage.setItem(KEY, JSON.stringify(values())); document.getElementById('time-steps-status').textContent = 'Saved on this device.'; } catch (reason) { showError(reason); document.getElementById('time-steps-status').textContent = 'Not saved.'; } }
function load() { try { const raw = localStorage.getItem(KEY); if (raw) { const data = JSON.parse(raw); if (!validSaved(data)) throw Error('bad save'); fill(data); document.getElementById('time-steps-status').textContent = 'Saved calculation loaded from this device.'; } } catch { document.getElementById('time-steps-status').textContent = 'Saved calculation could not be read. Start a new one.'; } }
function remove() { if (!localStorage.getItem(KEY)) { document.getElementById('time-steps-status').textContent = 'There is no saved calculation.'; return; } if (!window.confirm('Delete the calculation saved on this device?')) return; localStorage.removeItem(KEY); document.getElementById('time-steps-status').textContent = 'Saved calculation deleted.'; }
document.getElementById('time-steps-example').addEventListener('click', example);
document.getElementById('time-steps-calculate').addEventListener('click', () => { try { calculate(); document.getElementById('time-steps-status').textContent = 'Not saved'; } catch (reason) { showError(reason); } });
document.getElementById('time-steps-save').addEventListener('click', save); document.getElementById('time-steps-delete').addEventListener('click', remove);
ids.forEach(name => el(name).addEventListener('input', () => { try { if (el('appointment').value && el('preparation').value && el('travel').value) calculate(); } catch (reason) { showError(reason); } }));
load();
