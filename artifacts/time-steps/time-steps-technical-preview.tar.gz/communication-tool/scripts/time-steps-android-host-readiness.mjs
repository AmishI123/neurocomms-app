import {accessSync, constants, existsSync, mkdirSync, readFileSync, writeFileSync} from 'node:fs';
import {execFileSync} from 'node:child_process';
import {resolve} from 'node:path';

const root = resolve(new URL('..', import.meta.url).pathname);
const sdk = process.env.ANDROID_SDK_ROOT || process.env.ANDROID_HOME || '/home/mehta/Android/Sdk';
const adb = process.env.ADB_PATH || resolve(sdk, 'platform-tools/adb');
const emulator = process.env.EMULATOR_PATH || resolve(sdk, 'emulator/emulator');
const outputPath = resolve(root, process.argv.find(value => value.startsWith('--output='))?.slice(9) || 'ai-evaluation/results/time-steps-android-host-readiness.json');
const run = (command, args) => { try { return {ok:true, output:execFileSync(command, args, {encoding:'utf8', timeout:5000}).trim()}; } catch (error) { return {ok:false, output:`${error.stdout || ''}${error.stderr || ''}`.trim(), error:error.message}; } };
const deviceResult = run(adb, ['devices', '-l']);
const devices = deviceResult.output.split(/\r?\n/).slice(1).map(line => line.trim().split(/\s+/)).filter(fields => fields.length >= 2 && fields[0] && fields[1]).map(fields => ({serial:fields[0], state:fields[1]}));
const avdResult = run(emulator, ['-list-avds']);
const avds = avdResult.output.split(/\r?\n/).map(value => value.trim()).filter(Boolean);
const kvmPath = '/dev/kvm';
let kvmAccessible = false;
try { accessSync(kvmPath, constants.R_OK | constants.W_OK); kvmAccessible = true; } catch {}
const authorizedTargets = devices.filter(device => device.state === 'device');
const passed = authorizedTargets.length === 1;
const nextAction = passed
  ? 'Run npm run mobile:android:time-steps -- --serial=<authorized-target> --dedicated-test-target.'
  : kvmAccessible
    ? 'Connect exactly one authorized Android target, then rerun the native journey.'
    : 'Connect an authorized Android target, or grant this runner access to /dev/kvm for the installed AVD, then rerun the native journey.';
const result = {
  schemaVersion: 1,
  auditType: 'time-steps-android-host-readiness',
  generatedAt: new Date().toISOString(),
  passed,
  sdk,
  devices,
  authorizedTargetCount: authorizedTargets.length,
  avds,
  kvm: {path:kvmPath, exists:existsSync(kvmPath), accessible:kvmAccessible},
  nextAction,
  evidenceBoundary: 'Host readiness is not native product acceptance. It does not establish calculation behavior, usefulness, accessibility benefit, or human review.'
};
mkdirSync(resolve(outputPath, '..'), {recursive:true});
writeFileSync(outputPath, `${JSON.stringify(result, null, 2)}\n`);
console.log(JSON.stringify({...result, output:outputPath.replace(`${root}/`, '')}, null, 2));
if (!passed) process.exitCode = 1;
