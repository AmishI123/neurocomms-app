import {existsSync, mkdirSync, writeFileSync, readFileSync} from 'node:fs';
import {execFileSync} from 'node:child_process';
import {resolve} from 'node:path';
import {createHash} from 'node:crypto';
import {adbPath, toolchainEnv} from './android-toolchain.mjs';
import {restartAndroidView} from './android-view-restart.mjs';

// Explicit opt-in: installs and force-stops this app on one dedicated target only.
const serial = process.argv.find(arg => arg.startsWith('--serial='))?.slice(9);
if (!serial || !process.argv.includes('--dedicated-test-target')) {
  console.error('Requires --serial=<target> --dedicated-test-target. Use only a dedicated fictional-data installation.');
  process.exit(1);
}
const root = resolve(new URL('..', import.meta.url).pathname);
const apk = resolve(root, 'android/app/build/outputs/apk/debug/app-debug.apk');
const pkg = 'org.phrasestudio.app';
const env = toolchainEnv();
const adb = (args, timeout=15000) => execFileSync(adbPath, args, {encoding:'utf8', env, timeout});
const target = (args, timeout) => adb(['-s', serial, ...args], timeout);
const deviceSnapshot = () => {
  let listing = '';
  try { listing = adb(['devices', '-l']); } catch (error) { listing = `${error.stdout || ''}${error.stderr || ''}`.trim(); }
  // `adb devices -l` has emitted both tab- and space-separated rows across
  // tool versions. Parse the first whitespace-delimited field so an offline
  // target is reported as offline rather than incorrectly reported missing.
  const line = listing.split(/\r?\n/).find(value => value.trim().split(/\s+/)[0] === serial) || null;
  const state = line ? line.split(/\s+/)[1] || 'unknown' : 'missing';
  return {serial, state, listing: listing.trim().slice(-4000)};
};
const completed = [];
const startedAt = new Date().toISOString();
const reportPath = resolve(root, process.env.PHRASE_STUDIO_TIME_STEPS_ANDROID_REPORT || 'ai-evaluation/results/android-time-steps-journey.json');
const writeReport = report => { mkdirSync(resolve(reportPath, '..'), {recursive:true}); writeFileSync(reportPath, `${JSON.stringify(report, null, 2)}\n`); };
let device;
try {
  if (!existsSync(apk)) throw Error('Build the debug APK first.');
  const devices = adb(['devices']).split(/\r?\n/).filter(line => /\tdevice$/.test(line)).map(line => line.split('\t')[0]);
  if (devices.length !== 1 || devices[0] !== serial) throw Error('Connect only the named authorized dedicated target.');
  if (target(['shell', 'getprop', 'sys.boot_completed']).trim() !== '1') throw Error('Android has not completed boot.');
  execFileSync(process.execPath, ['scripts/mobile-bundle-audit.mjs', `--apk=${apk}`], {cwd:root, env, timeout:60000, stdio:'pipe'});
  execFileSync(process.execPath, ['scripts/android-permission-audit.mjs', `--apk=${apk}`], {cwd:root, env, timeout:30000, stdio:'pipe'});
  target(['install', '-r', apk], 120000);
  target(['shell', 'am', 'start', '-W', '-n', `${pkg}/.MainActivity`], 30000);
  const {_android} = await import('playwright');
  const devicesForAutomation = await _android.devices({omitDriverInstall:true});
  device = devicesForAutomation.find(item => item.serial() === serial);
  if (!device) throw Error('The dedicated target is unavailable to WebView automation.');
  device.setDefaultTimeout(30000);
  async function attach() {
    const view = await device.webView({pkg}, {timeout:30000});
    const page = await view.page();
    page.setDefaultTimeout(30000);
    await page.locator('#home-add').waitFor({state:'attached'});
    return {page, view};
  }
  let {page, view} = await attach();
  const hasWork = await page.evaluate(() => ['phrase-studio-study-bridge-v1','phrase-studio-study-review-v1','phrase-studio-draft-v1','phrase-studio-library-v1'].some(key => localStorage.getItem(key) !== null));
  if (hasWork) throw Error('Existing work detected. Use a fresh dedicated test installation; no data was cleared.');
  completed.push('installed-and-attached-native-webview');
  await page.getByRole('button', {name:'Open support tools'}).click();
  await page.locator('#time-steps-panel').scrollIntoViewIfNeeded();
  await page.locator('#time-steps-example').click();
  if (!/09:00|9:00/.test(await page.locator('#time-steps-result').innerText()) || !/09:20|9:20/.test(await page.locator('#time-steps-result').innerText())) throw Error('Fictional example did not show expected time steps.');
  completed.push('calculated-fictional-appointment');
  await page.locator('#time-steps-travel').fill('45');
  if (!/08:45|8:45/.test(await page.locator('#time-steps-result').innerText())) throw Error('Changing travel time did not update the visible result.');
  completed.push('changed-travel-assumption-updated-result');
  await page.locator('#time-steps-save').click();
  if (!/Saved on this device/.test(await page.locator('#time-steps-status').innerText())) throw Error('Time Steps save confirmation was not visible.');
  const saved = await page.evaluate(() => localStorage.getItem('phrase-studio-time-steps-v1'));
  if (!saved) throw Error('Time Steps record was not stored locally.');
  completed.push('saved-fictional-calculation-locally');
  ({page, view} = await restartAndroidView({page, view, stop:() => target(['shell', 'am', 'force-stop', pkg]), launch:() => target(['shell', 'am', 'start', '-W', '-n', `${pkg}/.MainActivity`], 30000), attach}));
  await page.getByRole('button', {name:'Open support tools'}).click();
  await page.locator('#time-steps-panel').scrollIntoViewIfNeeded();
  if (await page.locator('#time-steps-travel').inputValue() !== '45') throw Error('Saved Time Steps assumption was not restored after native restart.');
  if (await page.evaluate(() => localStorage.getItem('phrase-studio-time-steps-v1')) !== saved) throw Error('Saved Time Steps record changed across native restart.');
  completed.push('native-restart-restored-local-calculation');
  page.once('dialog', dialog => dialog.accept());
  await page.locator('#time-steps-delete').click();
  if (!/deleted/i.test(await page.locator('#time-steps-status').innerText())) throw Error('Time Steps delete confirmation was not visible.');
  completed.push('deleted-fictional-calculation');
  const report = {schemaVersion:1, auditType:'android-time-steps-journey', startedAt, completedAt:new Date().toISOString(), passed:true, scope:'native-time-steps-calculation-save-restart-delete', serial, model:device.model(), androidVersion:target(['shell','getprop','ro.build.version.release']).trim(), apkSha256:createHash('sha256').update(readFileSync(apk)).digest('hex'), completed, notTested:['native-file-picker','offline-device-network','keyboard-and-safe-area','iOS','human-usefulness'], dataDisposition:'Fictional calculation only; deleted during the journey.'};
  writeReport(report);
  console.log(JSON.stringify({...report, reportPath}, null, 2));
} catch (error) {
  const snapshot = deviceSnapshot();
  const nextAction = snapshot.state === 'offline'
    ? 'Reconnect or restart the named emulator/device until adb devices reports device, then rerun this command.'
    : snapshot.state === 'unauthorized'
      ? 'Authorize USB debugging on the named device, then rerun this command.'
      : snapshot.state === 'missing'
        ? 'Connect or start the named dedicated target, then rerun this command.'
        : 'Use one dedicated target shown as device, then rerun this command.';
  const report = {schemaVersion:1, auditType:'android-time-steps-journey', startedAt, completedAt:new Date().toISOString(), passed:false, scope:'native-time-steps-calculation-save-restart-delete', serial, completed, errorCode:'native-time-steps-journey-failed', error:error.message, nativeJourneyVerified:false, device:snapshot, nextAction, limitation:'An incomplete run is not evidence of native acceptance.'};
  writeReport(report);
  console.error(JSON.stringify({...report, reportPath}, null, 2));
  process.exitCode = 1;
} finally { if (device) await device.close(); }
