import {existsSync, mkdirSync, writeFileSync} from 'node:fs';
import {spawnSync} from 'node:child_process';
import {resolve} from 'node:path';

const root = resolve(new URL('..', import.meta.url).pathname);
const output = resolve(root, process.argv.find(value => value.startsWith('--output='))?.slice(9) || 'ai-evaluation/results/time-steps-release-audit.json');
const browserLibs = process.env.PHRASE_STUDIO_BROWSER_LIBS;
const env = {...process.env};
if (browserLibs && existsSync(browserLibs)) env.LD_LIBRARY_PATH = [browserLibs, env.LD_LIBRARY_PATH].filter(Boolean).join(':');

function run(command, args) {
  const result = spawnSync(command, args, {cwd: root, env, encoding: 'utf8', maxBuffer: 20 * 1024 * 1024});
  return {passed: result.status === 0, status: result.status, signal: result.signal, output: `${result.stdout || ''}${result.stderr || ''}`.trim().slice(-12000)};
}

function jsonRun(command, args) {
  const result = run(command, args);
  let parsed = null;
  try { parsed = JSON.parse(result.output); } catch {}
  return {...result, parsed};
}

const checks = {};
checks.browserPreflight = jsonRun(process.execPath, ['scripts/browser-runtime-preflight.mjs']);
checks.browserTests = run(process.execPath, ['--test',
  '../product-specs/time-steps/tests/time-steps.test.cjs',
  '../product-specs/time-steps/tests/daylight-saving.test.cjs',
  '../product-specs/time-steps/tests/storage-boundaries.test.cjs',
  '../product-specs/time-steps/tests/release-status-render.test.cjs',
  'tests/time-steps-shell.test.cjs',
  'tests/product-contract.test.cjs',
  'tests/time-steps-judge-report.test.cjs'
]);
checks.mobileBundle = jsonRun(process.execPath, ['scripts/mobile-bundle-audit.mjs']);
checks.accessibility = jsonRun(process.execPath, ['scripts/accessibility-audit.mjs']);

const apk = resolve(root, 'android/app/build/outputs/apk/debug/app-debug.apk');
checks.androidPackage = existsSync(apk)
  ? jsonRun(process.execPath, ['scripts/mobile-bundle-audit.mjs', `--apk=${apk}`])
  : {passed: false, status: null, signal: null, output: 'Debug APK is not present; build it before running the package gate.', parsed: null};
checks.androidPermissions = existsSync(apk)
  ? jsonRun(process.execPath, ['scripts/android-permission-audit.mjs', `--apk=${apk}`])
  : {passed: false, status: null, signal: null, output: 'Skipped because the debug APK is missing.', parsed: null};

const passed = Object.values(checks).every(check => check.passed && (!check.parsed || check.parsed.passed !== false));
const report = {
  schemaVersion: 1,
  auditType: 'time-steps-release-audit',
  generatedAt: new Date().toISOString(),
  passed,
  scope: 'Scoped Time Steps browser, shared-shell, contract, mobile-bundle, and packaged-Android checks.',
  checks: Object.fromEntries(Object.entries(checks).map(([name, check]) => [name, {
    passed: check.passed && (!check.parsed || check.parsed.passed !== false),
    status: check.status,
    signal: check.signal,
    parsed: check.parsed,
    outputTail: check.output
  }])),
  notTested: ['native Android journey', 'iOS execution', 'human usefulness or accessibility benefit'],
  evidenceBoundary: 'A passing audit is engineering evidence only. It does not establish usefulness, accessibility benefit, clinical benefit, demand, or native-device acceptance.'
};
mkdirSync(resolve(output, '..'), {recursive: true});
writeFileSync(output, `${JSON.stringify(report, null, 2)}\n`);
console.log(JSON.stringify({auditType:report.auditType, passed:report.passed, output:output.replace(`${root}/`, ''), checks:Object.fromEntries(Object.entries(report.checks).map(([name, value]) => [name, value.passed]))}, null, 2));
if (!passed) process.exitCode = 1;
