import {createHash} from 'node:crypto';
import {existsSync, readFileSync, mkdirSync, writeFileSync} from 'node:fs';
import {execFileSync} from 'node:child_process';
import {resolve, join} from 'node:path';

const root = resolve(new URL('..', import.meta.url).pathname);
const output = resolve(root, process.argv.find(value => value.startsWith('--output='))?.slice(9) || 'ai-evaluation/results/time-steps-ios-audit.json');
const iosRoot = join(root, 'ios', 'App');
const requiredFiles = [
  'App.xcodeproj/project.pbxproj',
  'Podfile',
  'App/public/index.html',
  'App/public/time-steps.mjs',
  'App/public/time-steps.css'
];
const runtimeFiles = ['index.html', 'time-steps.mjs', 'time-steps.css'];
const hash = file => createHash('sha256').update(readFileSync(file)).digest('hex');
const command = name => { try { return execFileSync(name, ['--version'], {cwd:root, encoding:'utf8', stdio:['ignore','pipe','pipe']}).trim(); } catch { return null; } };
const filesPresent = requiredFiles.every(file => existsSync(join(iosRoot, file)));
const runtimeMatches = runtimeFiles.every(file => {
  const source = join(root, 'dist', file);
  const ios = join(iosRoot, 'App', 'public', file);
  return existsSync(source) && existsSync(ios) && hash(source) === hash(ios);
});
const xcodebuild = command('xcodebuild');
const cocoaPods = command('pod');
const checks = {
  iosShell: {passed: filesPresent, detail: filesPresent ? 'iOS project, Podfile, and Time Steps runtime files are present.' : 'One or more required iOS shell files are missing.'},
  syncedTimeStepsRuntime: {passed: runtimeMatches, detail: runtimeMatches ? 'The iOS public Time Steps files match the current mobile bundle.' : 'The iOS public Time Steps files do not match the current mobile bundle.'},
  xcode: {passed: Boolean(xcodebuild), detail: xcodebuild || 'xcodebuild is unavailable; run this gate on macOS with Xcode.'},
  cocoaPods: {passed: Boolean(cocoaPods), detail: cocoaPods || 'pod is unavailable; install CocoaPods before syncing iOS plugins.'}
};
const report = {
  schemaVersion: 1,
  auditType: 'time-steps-ios-audit',
  generatedAt: new Date().toISOString(),
  passed: Object.values(checks).every(check => check.passed),
  checks,
  notTested: ['iOS build', 'iOS simulator/device journey', 'human usefulness or accessibility benefit'],
  evidenceBoundary: 'This audit proves source and handoff readiness only. It does not prove an iOS build, native behavior, usefulness, or accessibility benefit.'
};
mkdirSync(resolve(output, '..'), {recursive:true});
writeFileSync(output, `${JSON.stringify(report, null, 2)}\n`);
console.log(JSON.stringify({auditType:report.auditType, passed:report.passed, output:output.replace(`${root}/`, ''), checks:Object.fromEntries(Object.entries(checks).map(([name, value]) => [name, value.passed]))}, null, 2));
if (!report.passed) process.exitCode = 1;
