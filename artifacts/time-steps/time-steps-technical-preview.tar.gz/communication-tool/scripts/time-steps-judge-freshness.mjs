import {mkdirSync, readFileSync, writeFileSync} from 'node:fs';
import {resolve} from 'node:path';

const root = resolve(new URL('..', import.meta.url).pathname);
const reportPath = resolve(root, process.argv.find(value => value.startsWith('--report='))?.slice(9) || 'ai-evaluation/results/time-steps-judge.json');
const outputPath = resolve(root, process.argv.find(value => value.startsWith('--output='))?.slice(9) || 'ai-evaluation/results/time-steps-judge-freshness.json');
const report = JSON.parse(readFileSync(reportPath, 'utf8'));
const evidence = Array.isArray(report.artifact?.evidence) ? report.artifact.evidence : [];
const required = [
  /^Standalone browser journey: 10 tests passed\b/,
  /^Shared Phrase Studio shell journey: 6 tests passed\b/,
  /^Product contract checks: 2 tests passed\b/
];
const missing = required.filter(pattern => !evidence.some(item => pattern.test(item))).map(pattern => pattern.source);
const passed = missing.length === 0;
const result = {
  schemaVersion: 1,
  auditType: 'time-steps-judge-freshness',
  generatedAt: new Date().toISOString(),
  passed,
  reportPath: reportPath.replace(`${root}/`, ''),
  expectedCurrentEvidence: ['10 standalone browser checks', '6 shared-shell checks', '2 product contract checks'],
  missing,
  nextAction: passed ? 'The stored judge evidence counts match the current scoped checks.' : 'Run the judge again with a working loopback LLM endpoint; do not edit the model report by hand.',
  evidenceBoundary: 'This is a freshness check only. It does not judge usefulness, accessibility benefit, clinical benefit, demand, or native-device acceptance.'
};
mkdirSync(resolve(outputPath, '..'), {recursive: true});
writeFileSync(outputPath, `${JSON.stringify(result, null, 2)}\n`);
console.log(JSON.stringify({...result, output: outputPath.replace(`${root}/`, '')}, null, 2));
if (!passed) process.exitCode = 1;
