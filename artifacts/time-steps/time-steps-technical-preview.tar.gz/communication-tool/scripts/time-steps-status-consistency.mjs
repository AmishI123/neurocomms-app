import {existsSync, mkdirSync, readFileSync, writeFileSync} from 'node:fs';
import {resolve} from 'node:path';

const root = resolve(new URL('..', import.meta.url).pathname);
const outputPath = resolve(root, process.argv.find(value => value.startsWith('--output='))?.slice(9) || 'ai-evaluation/results/time-steps-status-consistency.json');
const readJson = relative => JSON.parse(readFileSync(resolve(root, relative), 'utf8'));
const summary = readJson('ai-evaluation/results/time-steps-release-summary.json');
const manifest = readJson('ai-evaluation/results/time-steps-handoff-manifest.json');
const page = readFileSync(resolve(root, '../product-specs/time-steps/release-status.html'), 'utf8');
const checks = [];
const expectPage = (name, ...needles) => checks.push({name, passed: needles.every(needle => page.includes(needle)), needles});
expectPage('archive file count', `current archive contains ${manifest.files.length} explicit files`);
expectPage('technical preview decision', summary.technicalPreviewReady ? 'Ready for review' : 'Not ready');
expectPage('judge runtime gate', summary.checks.judgeRuntime ? 'LLM runtime' : 'LLM runtime</th><td class="not-ready">Not installed');
expectPage('judge freshness gate', summary.checks.judgeFreshness ? 'LLM judge record</th><td class="status">' : 'LLM judge record</th><td class="not-ready">Refresh required');
expectPage('Android native gate', summary.checks.androidNativeJourney ? 'Android native use</th><td class="status">' : 'Android native use</th><td class="not-ready">Not verified');
expectPage('Android host gate', summary.checks.androidHostReady ? 'Android host</th><td class="status">' : 'Android host</th><td class="not-ready">Target unavailable');
expectPage('iOS native gate', summary.checks.iosNativeExecution ? 'iOS</th><td class="status">' : 'iOS</th><td class="not-ready">Not built');
expectPage('signing gate', summary.checks.releaseOwnerSigning ? 'Release signing</th><td class="status">' : 'Release signing</th><td class="not-ready">Not done');
expectPage('human review gate', summary.checks.humanReview ? 'Human review</th><td class="status">' : 'Human review</th><td class="not-ready">Not done');
expectPage('broad release boundary', summary.broadReleaseReady ? 'broad release' : 'Open gates');
const result = {
  schemaVersion: 1,
  auditType: 'time-steps-status-consistency',
  generatedAt: new Date().toISOString(),
  passed: checks.every(check => check.passed),
  sourceSummary: 'ai-evaluation/results/time-steps-release-summary.json',
  sourceManifest: 'ai-evaluation/results/time-steps-handoff-manifest.json',
  checks,
  evidenceBoundary: 'This checks agreement between two engineering records. It does not establish usefulness, accessibility benefit, clinical benefit, demand, or human review.'
};
mkdirSync(resolve(outputPath, '..'), {recursive:true});
writeFileSync(outputPath, `${JSON.stringify(result, null, 2)}\n`);
console.log(JSON.stringify({...result, output: outputPath.replace(`${root}/`, '')}, null, 2));
if (!result.passed) process.exitCode = 1;
