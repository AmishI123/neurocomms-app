import {createHash} from 'node:crypto';
import {existsSync, mkdirSync, readFileSync, writeFileSync} from 'node:fs';
import {resolve} from 'node:path';

const root = resolve(new URL('..', import.meta.url).pathname);
const repo = resolve(root, '..');
const requireBroadRelease = process.argv.includes('--require-broad-release');
const outputPath = resolve(root, process.argv.find(value => value.startsWith('--output='))?.slice(9) || 'ai-evaluation/results/time-steps-release-summary.json');
const readJson = relative => { try { return JSON.parse(readFileSync(resolve(root, relative), 'utf8')); } catch { return null; } };
const releaseAudit = readJson('ai-evaluation/results/time-steps-release-audit.json');
const runtime = readJson('ai-evaluation/results/time-steps-judge-runtime.json');
const freshness = readJson('ai-evaluation/results/time-steps-judge-freshness.json');
const reproducibility = readJson('ai-evaluation/results/time-steps-handoff-reproducibility.json');
const native = readJson('ai-evaluation/results/android-time-steps-journey.json');
const androidHost = readJson('ai-evaluation/results/time-steps-android-host-readiness.json');
const ios = readJson('ai-evaluation/results/time-steps-ios-audit.json');
const signing = readJson('ai-evaluation/results/time-steps-signing-audit.json');
const manifest = readJson('ai-evaluation/results/time-steps-handoff-manifest.json');
const archivePath = manifest?.archive?.path ? resolve(repo, manifest.archive.path) : null;
const archiveHash = archivePath && existsSync(archivePath) ? createHash('sha256').update(readFileSync(archivePath)).digest('hex') : null;
const checks = {
  engineeringAudit: Boolean(releaseAudit?.passed),
  archiveIntegrity: Boolean(manifest?.fictionalOnly === true && manifest?.containsPrivateUserData === false && archiveHash === manifest?.archive?.sha256),
  reproduciblePackage: Boolean(reproducibility?.passed),
  judgeRuntime: Boolean(runtime?.passed),
  judgeFreshness: Boolean(freshness?.passed),
  androidNativeJourney: Boolean(native?.passed && native.completed?.length === 5),
  androidHostReady: Boolean(androidHost?.passed),
  iosNativeExecution: Boolean(ios?.passed && ios.checks?.xcode?.passed && ios.checks?.cocoaPods?.passed),
  releaseOwnerSigning: Boolean(signing?.distributable),
  humanReview: false
};
const technicalPreviewReady = checks.engineeringAudit && checks.archiveIntegrity && checks.reproduciblePackage;
const broadReleaseReady = technicalPreviewReady && checks.judgeRuntime && checks.judgeFreshness && checks.androidHostReady && checks.androidNativeJourney && checks.iosNativeExecution && checks.releaseOwnerSigning && checks.humanReview;
const result = {
  schemaVersion: 1,
  auditType: 'time-steps-release-summary',
  generatedAt: new Date().toISOString(),
  passed: technicalPreviewReady && (!requireBroadRelease || broadReleaseReady),
  technicalPreviewReady,
  broadReleaseReady,
  requiredBroadRelease: requireBroadRelease,
  checks,
  openGates: Object.entries(checks).filter(([, passed]) => !passed).map(([name]) => name),
  nextActions: {
    judgeRuntime: runtime?.nextAction || 'Run the judge runtime preflight.',
    judgeFreshness: freshness?.nextAction || 'Run the judge freshness check.',
    androidNativeJourney: native?.nextAction || 'Run the Android journey on one authorized target.',
    androidHostReady: androidHost?.nextAction || 'Run the Android host readiness check.',
    iosNativeExecution: ios?.checks?.xcode?.detail || 'Run the iOS audit on macOS with Xcode and CocoaPods.',
    releaseOwnerSigning: signing?.distributable ? 'Release APK signing evidence is present.' : 'Sign the release APK on the release-owner machine using the secret-store process; keep credentials out of this checkout.',
    humanReview: 'Complete an approved fictional-task review with an independent reviewer; do not infer usefulness from automation.'
  },
  evidenceBoundary: 'Technical preview readiness is engineering evidence only. This summary does not establish usefulness, accessibility benefit, clinical benefit, demand, or human review.'
};
mkdirSync(resolve(outputPath, '..'), {recursive: true});
writeFileSync(outputPath, `${JSON.stringify(result, null, 2)}\n`);
console.log(JSON.stringify({...result, output: outputPath.replace(`${root}/`, '')}, null, 2));
if (!technicalPreviewReady || (requireBroadRelease && !broadReleaseReady)) process.exitCode = 1;
