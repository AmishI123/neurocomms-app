import {createHash} from 'node:crypto';
import {existsSync, mkdirSync, readFileSync, writeFileSync} from 'node:fs';
import {spawnSync} from 'node:child_process';
import {resolve, join, relative} from 'node:path';

const root = resolve(new URL('..', import.meta.url).pathname);
const repo = resolve(root, '..');
const artifactRoot = join(repo, 'artifacts', 'time-steps');
const archive = join(artifactRoot, 'time-steps-technical-preview.tar.gz');
const manifestPath = resolve(root, process.argv.find(value => value.startsWith('--output='))?.slice(9) || 'ai-evaluation/results/time-steps-handoff-manifest.json');
const files = [
  'NEXT-MEATY-GOAL-TIME-STEPS.md',
  'NEXT-MEATY-GOAL-TIME-STEPS-RELEASE-HARDENING.md',
  'product-specs/time-steps/index.html',
  'product-specs/time-steps/app.js',
  'product-specs/time-steps/styles.css',
  'product-specs/time-steps/PRD.md',
  'product-specs/time-steps/README.md',
  'product-specs/time-steps/verification.md',
  'product-specs/time-steps/decision-report.html',
  'product-specs/time-steps/reviewer-guide.md',
  'product-specs/time-steps/reviewer-form.html',
  'product-specs/time-steps/native-platform-handoff.md',
  'product-specs/time-steps/release-status.html',
  'communication-tool/time-steps.mjs',
  'communication-tool/time-steps.css',
  'communication-tool/scripts/time-steps-handoff-package.mjs',
  'communication-tool/scripts/time-steps-handoff-reproducibility.mjs',
  'communication-tool/scripts/time-steps-handoff-verify.mjs',
  'communication-tool/scripts/time-steps-judge-freshness.mjs',
  'communication-tool/scripts/time-steps-judge-runtime.mjs',
  'communication-tool/scripts/time-steps-release-summary.mjs',
  'communication-tool/scripts/time-steps-status-consistency.mjs',
  'communication-tool/scripts/time-steps-android-host-readiness.mjs',
  'communication-tool/scripts/time-steps-release-audit.mjs',
  'communication-tool/scripts/time-steps-ios-audit.mjs',
  'communication-tool/scripts/android-time-steps-journey.mjs',
  'communication-tool/docs/android-release-signing.md',
  'communication-tool/ai-evaluation/results/time-steps-release-audit.json',
  'communication-tool/ai-evaluation/results/time-steps-ios-audit.json',
  'communication-tool/ai-evaluation/results/time-steps-signing-audit.json',
  'communication-tool/ai-evaluation/results/android-time-steps-journey.json',
  'communication-tool/ai-evaluation/results/time-steps-android-host-readiness.json',
  'communication-tool/ai-evaluation/results/time-steps-judge.json',
  'communication-tool/ai-evaluation/results/time-steps-judge.html',
  'communication-tool/ai-evaluation/results/time-steps-judge-freshness.json',
  'communication-tool/ai-evaluation/results/time-steps-judge-runtime.json'
];
const missing = files.filter(file => !existsSync(join(repo, file)));
if (missing.length) { console.error(JSON.stringify({passed:false, missing}, null, 2)); process.exit(1); }
mkdirSync(artifactRoot, {recursive:true});
// Normalize archive metadata so the same source files produce the same bytes
// on different machines and after a checkout changes file timestamps.
const tar = spawnSync('tar', ['--sort=name', '--mtime=@0', '--owner=0', '--group=0', '--numeric-owner', '-czf', archive, ...files], {cwd:repo, encoding:'utf8', maxBuffer:2 * 1024 * 1024});
if (tar.status !== 0) { console.error(tar.stderr || 'tar failed'); process.exit(tar.status || 1); }
const fileRecords = files.map(file => { const bytes = readFileSync(join(repo, file)); return {file, bytes:bytes.byteLength, sha256:createHash('sha256').update(bytes).digest('hex')}; });
const archiveBytes = readFileSync(archive);
const report = {
  schemaVersion: 1,
  auditType: 'time-steps-handoff-package',
  generatedAt: new Date().toISOString(),
  passed: true,
  fictionalOnly: true,
  containsPrivateUserData: false,
  archive: {path:relative(repo, archive), bytes:archiveBytes.byteLength, sha256:createHash('sha256').update(archiveBytes).digest('hex')},
  files: fileRecords,
  notTested: ['native Android journey', 'iOS build and execution', 'human usefulness or accessibility benefit'],
  evidenceBoundary: 'This package contains engineering and fictional review evidence only. It does not establish usefulness, accessibility benefit, clinical benefit, demand, or native-device acceptance.'
};
mkdirSync(resolve(manifestPath, '..'), {recursive:true});
writeFileSync(manifestPath, `${JSON.stringify(report, null, 2)}\n`);
console.log(JSON.stringify({auditType:report.auditType, passed:report.passed, archive:report.archive, manifest:relative(repo, manifestPath), fileCount:files.length}, null, 2));
