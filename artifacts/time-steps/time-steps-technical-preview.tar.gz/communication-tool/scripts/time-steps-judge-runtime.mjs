import {existsSync, mkdirSync, writeFileSync} from 'node:fs';
import {resolve} from 'node:path';

const root = resolve(new URL('..', import.meta.url).pathname);
const runtime = resolve(root, '.benchmark-runtime');
const serverPath = resolve(runtime, 'llama-b10853', 'llama-server');
const modelPath = resolve(runtime, 'Qwen3.5-0.8B-Q8_0.gguf');
const proxyUrl = process.env.PHRASE_STUDIO_JUDGE_URL || 'http://127.0.0.1:8787/phrase';
const outputPath = resolve(root, process.argv.find(value => value.startsWith('--output='))?.slice(9) || 'ai-evaluation/results/time-steps-judge-runtime.json');

let proxyReachable = false;
let proxyError = null;
try {
  const url = new URL(proxyUrl);
  if (!['127.0.0.1', 'localhost', '::1'].includes(url.hostname)) throw Error('Only loopback judge URLs are allowed.');
  const response = await fetch(url, {method: 'OPTIONS', signal: AbortSignal.timeout(1500)});
  proxyReachable = response.status < 500;
  if (!proxyReachable) proxyError = `Loopback proxy returned HTTP ${response.status}.`;
} catch (error) { proxyError = error.message; }

const runtimePresent = existsSync(serverPath) && existsSync(modelPath);
const ready = runtimePresent && proxyReachable;
const nextAction = ready
  ? 'Run npm run ai:time-steps-judge -- --url=http://127.0.0.1:8787/phrase.'
  : !runtimePresent
    ? 'Install or provide the pinned local llama runtime and model, then run npm run ai:local.'
    : 'Start the local model and proxy with npm run ai:local, then rerun this preflight.';
const report = {
  schemaVersion: 1,
  auditType: 'time-steps-judge-runtime',
  generatedAt: new Date().toISOString(),
  passed: ready,
  loopbackOnly: true,
  runtime: {serverPath, modelPath, serverExists: existsSync(serverPath), modelExists: existsSync(modelPath)},
  proxy: {url: proxyUrl, reachable: proxyReachable, error: proxyError},
  nextAction,
  evidenceBoundary: 'Runtime readiness is not a model judgment. It does not establish usefulness, accessibility benefit, clinical benefit, demand, or human review.'
};
mkdirSync(resolve(outputPath, '..'), {recursive: true});
writeFileSync(outputPath, `${JSON.stringify(report, null, 2)}\n`);
console.log(JSON.stringify({...report, output: outputPath.replace(`${root}/`, '')}, null, 2));
if (!ready) process.exitCode = 1;
