import {createHash} from 'node:crypto';
import {existsSync, mkdtempSync, readFileSync, readdirSync, statSync, rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {spawnSync} from 'node:child_process';
import {resolve, join} from 'node:path';

const root = resolve(new URL('..', import.meta.url).pathname);
const repo = resolve(root, '..');
const manifestPath = resolve(root, process.argv.find(value => value.startsWith('--manifest='))?.slice(11) || 'ai-evaluation/results/time-steps-handoff-manifest.json');
const manifest = JSON.parse(readFileSync(manifestPath, 'utf8'));
const archive = join(repo, manifest.archive.path);
const hash = file => createHash('sha256').update(readFileSync(file)).digest('hex');
const archiveHash = existsSync(archive) ? hash(archive) : null;
const temp = mkdtempSync(join(tmpdir(), 'time-steps-handoff-'));
let passed = false;
let checks;
try {
  const extract = existsSync(archive) ? spawnSync('tar', ['-xzf', archive, '-C', temp], {encoding:'utf8'}) : {status:1, stderr:'Archive is missing.'};
  const expected = new Map(manifest.files.map(item => [item.file, item]));
  const actual = [];
  function walk(directory, prefix = '') {
    for (const entry of readdirSync(directory, {withFileTypes:true})) {
      const file = join(directory, entry.name); const relative = prefix ? `${prefix}/${entry.name}` : entry.name;
      if (entry.isDirectory()) walk(file, relative); else actual.push(relative);
    }
  }
  if (extract.status === 0) walk(temp);
  const fileChecks = [...expected.entries()].map(([file, expectedFile]) => {
    const actualPath = join(temp, file); const exists = existsSync(actualPath) && statSync(actualPath).isFile();
    const bytes = exists ? statSync(actualPath).size : null; const sha256 = exists ? hash(actualPath) : null;
    return {file, passed:exists && bytes === expectedFile.bytes && sha256 === expectedFile.sha256, exists, bytes, sha256};
  });
  const readExtractedJson = file => {
    try { return JSON.parse(readFileSync(join(temp, file), 'utf8')); } catch { return null; }
  };
  const releaseAudit = readExtractedJson('communication-tool/ai-evaluation/results/time-steps-release-audit.json');
  const native = readExtractedJson('communication-tool/ai-evaluation/results/android-time-steps-journey.json');
  const ios = readExtractedJson('communication-tool/ai-evaluation/results/time-steps-ios-audit.json');
  const signing = readExtractedJson('communication-tool/ai-evaluation/results/time-steps-signing-audit.json');
  const judgeFreshness = readExtractedJson('communication-tool/ai-evaluation/results/time-steps-judge-freshness.json');
  const judgeRuntime = readExtractedJson('communication-tool/ai-evaluation/results/time-steps-judge-runtime.json');
  const evidenceSemantics = {
    releaseAuditPassed: releaseAudit?.passed === true,
    nativeBoundary: native?.passed === true ? native.completed?.length === 5 : native?.nativeJourneyVerified === false && typeof native?.limitation === 'string',
    iosBoundary: ios?.passed === true ? ios.checks?.xcode?.passed === true && ios.checks?.cocoaPods?.passed === true : typeof ios?.evidenceBoundary === 'string',
    signingBoundary: signing?.distributable === (signing?.signingState === 'signed'),
    judgeFreshnessBoundary: judgeFreshness?.passed === true || typeof judgeFreshness?.nextAction === 'string',
    judgeRuntimeBoundary: judgeRuntime?.passed === true || typeof judgeRuntime?.nextAction === 'string'
  };
  checks = {
    archiveExists: existsSync(archive),
    archiveHash: archiveHash === manifest.archive.sha256,
    archiveExtracted: extract.status === 0,
    exactFileSet: actual.length === expected.size && actual.every(file => expected.has(file)),
    fileHashes: fileChecks.every(check => check.passed),
    evidenceSemantics: Object.values(evidenceSemantics).every(Boolean),
    fictionalOnly: manifest.fictionalOnly === true,
    containsPrivateUserData: manifest.containsPrivateUserData === false
  };
  passed = Object.values(checks).every(Boolean);
  console.log(JSON.stringify({auditType:'time-steps-handoff-verify', passed, manifest:manifestPath.replace(`${root}/`, ''), archive:manifest.archive, checks, evidenceSemantics, fileChecks}, null, 2));
} finally { rmSync(temp, {recursive:true, force:true}); }
if (!passed) process.exitCode = 1;
