import {createHash} from 'node:crypto';
import {mkdirSync, readFileSync, writeFileSync} from 'node:fs';
import {spawnSync} from 'node:child_process';
import {resolve} from 'node:path';

const root = resolve(new URL('..', import.meta.url).pathname);
const manifestPath = resolve(root, 'ai-evaluation/results/time-steps-handoff-manifest.json');
const outputPath = resolve(root, process.argv.find(value => value.startsWith('--output='))?.slice(9) || 'ai-evaluation/results/time-steps-handoff-reproducibility.json');

function packageOnce() {
  const result = spawnSync(process.execPath, ['scripts/time-steps-handoff-package.mjs'], {cwd: root, encoding: 'utf8', maxBuffer: 4 * 1024 * 1024});
  let manifest = null;
  try { manifest = JSON.parse(readFileSync(manifestPath, 'utf8')); } catch {}
  const archiveBytes = manifest?.archive?.path ? readFileSync(resolve(root, '..', manifest.archive.path)) : null;
  return {
    status: result.status,
    outputTail: `${result.stdout || ''}${result.stderr || ''}`.trim().slice(-4000),
    archive: manifest?.archive || null,
    byteHash: archiveBytes ? createHash('sha256').update(archiveBytes).digest('hex') : null
  };
}

const first = packageOnce();
const second = packageOnce();
const passed = first.status === 0 && second.status === 0
  && first.archive?.sha256 === second.archive?.sha256
  && first.byteHash === second.byteHash
  && first.byteHash === first.archive?.sha256;
const report = {
  schemaVersion: 1,
  auditType: 'time-steps-handoff-reproducibility',
  generatedAt: new Date().toISOString(),
  passed,
  runs: [first, second],
  evidenceBoundary: 'This proves byte-stable packaging for the current source checkout. It does not establish native acceptance, usefulness, accessibility benefit, clinical benefit, or demand.'
};
mkdirSync(resolve(outputPath, '..'), {recursive: true});
writeFileSync(outputPath, `${JSON.stringify(report, null, 2)}\n`);
console.log(JSON.stringify({auditType: report.auditType, passed, output: outputPath.replace(`${root}/`, ''), archiveSha256: second.archive?.sha256 || null}, null, 2));
if (!passed) process.exitCode = 1;
