# Evaluating a personalization review step for suggested communication materials

**Mentor-review proposal · 7 September 2026 · Draft v0.1.0**

## Problem and question

Adults preparing supplemental communication materials can accept suggestions that are repetitive or poorly matched to a person and an activity. A brief review might improve those materials, but could also add effort without useful gains. The closest authoring study found mixed quality alongside efficiency gains ([Zastudil et al., ASSETS 2025](https://arxiv.org/html/2507.21811v1)). The [focused evidence check](evidence-check.md) distinguishes our question from existing tools and newer personalization research.

**Question:** Among adult communication-material preparers, does an editor with three personalization-review prompts improve scenario fit compared with the same editor without those prompts?

**Hypothesis:** The review group will produce higher scenario-fit ratings. Preparation time, effort and variety will be reported separately; faster work or more cards alone will not count as improvement.

## What is ready

The local Phrase Studio demo contains an ordinary editor and an editor with review prompts. Both show identical fictional profiles, activity details and six fixed starter cards per activity. Both support adding, editing and removing cards. The review version adds optional prompts about scenario fit, communication functions and unnecessary repetition. There is no automatic scoring or live AI.

Two original, structurally matched cases concern planting and collage. Each includes an interest, a stated dislike, an available alternative and the freedom to decline participation. The full existing communication system remains available in each scenario. These small sets are supplemental; the tool does not prescribe a child's vocabulary.

## Proposed experiment

Randomly assign consenting adult preparers to one editor version for both tasks. Counterbalance the two activity orders within each group. A participant should not try the other version first: review prompts can teach a strategy that carries into later ordinary editing. This parallel-group design avoids that crossover problem, at the cost of needing more participants and tolerating variation in prior experience.

Provisional feasibility target: 16 completed adult sessions, four per condition/order cell, subject to mentor review and recruitment feasibility. This is a practical planning target, not a power calculation. A confirmatory claim would require a justified sample size using defensible variance and meaningful-effect assumptions. Keep eligibility to one defined preparer population; do not silently pool trained clinicians, untrained students and institute staff.

Each session includes consent, a common controls demonstration, two preparation tasks, and optional effort ratings and comments. Plan around 25–35 minutes; this duration has not been validated with people. The detailed [protocol](study-protocol.md) defines deviations, withdrawal and missing data.

## Outcomes and interpretation

Primary: each adult's mean scenario-fit score across the two tasks, independently rated by two qualified reviewers using the draft 0–4 rubric. Average raters within task, then tasks within adult. Compare the group means at the adult level. Cards and repeated tasks are not independent participants.

Secondary: active preparation time, wall time, reported effort, unsupported cards, communication functions represented, redundancy and editing counts. Report raw distributions and uncertainty. The rubric is an original, unvalidated instrument: raters must refine and freeze it before participant data are collected.

A higher fit score with manageable effort would support a larger evaluation. No improvement, increased unsupported assertions, or burdensome extra time would argue for redesign. A noisy or null pilot cannot establish equivalence. Two contrived scenarios cannot establish generalized authoring quality, child satisfaction, communication benefit or treatment efficacy.

## Mentor decisions needed before a study

Confirm the preparer population and recruitment setting; assess whether the cases and prompts are realistic; refine the scoring anchors without rewarding superficial checklist copying; decide the sample and time budget; identify raters and the applicable review route. Agree on a practically worthwhile difference and acceptable time cost before outcomes are known.

The prototype is ready for discussion and researcher-only rehearsal. It labels all exports **demonstration**. No participant study has been run. Adult prototype testing can require prior review; ISEF rules specifically include testing student applications with other people ([Society for Science](https://www.societyforscience.org/isef/international-rules/human-participants/)). The institution and intended fair/publication route still need to be identified.

## Deliverables

Working local demo; focused evidence check; two fictional scenarios; scoring rubric with worked examples; draft study protocol; example materials and export formats; verification report. The next milestone after mentor feedback and applicable approval is a frozen study release and actual data collection.
