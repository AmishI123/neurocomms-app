# Focused gap check

7 September 2026 · Project A · Targeted follow-up, not a systematic review

## Decision

Proceed with a bounded authoring-interface feasibility project. The proposed contribution is the incremental effect of three review prompts on an otherwise identical editor, using fixed suggestions and fictional scenarios. We did not identify that exact comparison in the inspected sources. This is not proof of global novelty. Personalization, editable suggestions, fictional case evaluation, and broad communication functions are already established ideas.

## Closest evidence and competing approaches

| Source and access | What it establishes | Implication for this project |
|---|---|---|
| Zastudil et al., ASSETS 2025, [Helping or Homogenizing?](https://arxiv.org/html/2507.21811v1), full text, especially §§4.2, 6–7 | The study compared AI-supported VSD authoring with Snap Scene using hypothetical cases and counterbalanced tasks. Seventeen pre-service SLPs participated; one was excluded from analysis. Efficiency and confidence improved, but quality findings were mixed, including relevance and social-function concerns. | Closest comparator. Our ordinary editor already permits edits, so the question is whether explicit review adds value. This text-card prototype does not reproduce their visual scene display or establish child outcomes. |
| Zastudil et al., ASSETS 2024, [Exploring the use of Generative AI…](https://arxiv.org/html/2408.11137v1), full text §§2–3 | Compared expert and model-generated communication options and included expert interviews. | Generating options and having adults assess them are prior work, not our novelty claim. |
| Choi et al., CHI 2025, [AACessTalk](https://arxiv.org/html/2409.09641v4), full text | Contextual cards and adult guidance were deployed with 11 child–parent pairs for two weeks. | Guidance is not a new category. Our question concerns adult preparation under controlled conditions, not home conversation. |
| Frisch et al., 2026 workshop paper, [It’s Complicated](https://arxiv.org/html/2606.24854v1), full text introduction and evaluation discussion; posted June 23 | A position paper proposing broader evaluation of AI-powered AAC, including effort, identity and context. | Supports reporting multiple outcomes. It is not a trial validating our prompts or rubric. |
| Weinberg et al., CHI 2026, [I, Robot?](https://doi.org/10.1145/3772318.3790310), indexed publisher abstract and discussion | One author’s longitudinal autoethnographic investigation of personalized AAC described issues of agency, identity and privacy. | Personalization can introduce new problems. A scenario preference must not be treated as a statement of current intent. Transfer to children is untested here. |
| Pal et al., IUI 2026, [SPICA](https://doi.org/10.1145/3742413.3789116), indexed publisher text; direct DOI fetch failed | A framework using personal knowledge retrieval for AAC conversation. The text describes synthetic-profile evaluation and a real-user case. | Personalized generation is an active field. This does not evaluate our adult authoring checklist. Abstract/body synthetic-profile counts differ (200/205); no numerical performance claim is used here. |
| Tobii Dynavox, [Snap Scene quick-start guide](https://download.mytobiidynavox.com/SnapScene/documents/SnapScene_quick_start_guide_en_1.2.pdf), official PDF | Supports creating scenes, hotspots, labels and recordings. | Manual authoring and editing already exist. A text-card editor is not a replacement or a feature-complete comparison. |
| AssistiveWare, [Proloquo for professionals](https://www.assistiveware.com/products/proloquo-and-proloquo-coach-for-aac-professionals), official product page | Describes vocabulary personalization, multiple communication functions and partner coaching. | Neither personalization nor going beyond requests is novel by itself. Product claims establish features, not independent efficacy. |
| Macomb ISD, [Personal Access Method and AAC Systems](https://www.misd.net/AssistiveTech/AAC/AACsystems.html), official education-service page | Lists personalization resources and an existing device-setup checklist. | We cannot claim the first AAC checklist. The checklist itself was not obtained or evaluated. |

## Search record and limits

Queries included `AAC communication material authoring personalization review checklist AI visual scene display 2025 2026 study`, `"AAC" "personalization" "checklist" authoring`, `"AAC" "review" "suggestions" "2026" authoring`, `"communication" "authoring" "review checklist" AAC`, `"AAC" "personalization review" study`, and the full SPICA title. Official Snap Scene and AssistiveWare pages were also searched. Follow-up reads prioritized methods, comparison conditions and limitations. Same-acronym results from committees, coding and regulations were excluded. Review articles and unverified aggregator summaries were not used as primary evidence.

This search is sufficient to scope a prototype, not certify publication novelty. No exhaustive citation-network/database search was performed. A mentor should check the exact prompts and comparison against specialist literature before finalizing a submission claim. A useful local replication is still possible if equivalent work exists.

## Scope correction

Use the working title **“Evaluating a personalization review step for suggested communication materials.”** The demo contains no live AI and makes no model-effectiveness claim. An AI-specific extension would need frozen, documented model outputs, a wider scenario sample, and a separate model-quality question.
