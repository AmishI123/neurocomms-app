# Draft scoring rubric

Version 0.1.0 · Original project instrument · Not clinically validated

Rate the final **supplemental set against its fictional scenario**. Do not infer a real child's wishes, diagnosis, linguistic level or comprehension. General-purpose words can be useful even when not explicitly quoted in the case. No target number of cards, required exact phrase, or bonus for copying the person's interest exists.

## Primary: scenario fit, one set-level score from 0 to 4

| Score | Anchor |
|---|---|
| 0 | No usable relation to the activity or stated context; the set would need replacement. |
| 1 | Some relevant content, but substantial misleading, incompatible or unusable content requires major revision. |
| 2 | A usable starting set with a significant mismatch or omission of available context; revision is needed. |
| 3 | A largely usable set reflecting the activity and available personal context, with only minor issues. |
| 4 | A coherently useful set for the activity and stated context, without material unsupported assertions; little revision needed on this dimension. |

Choose the best anchor and write one sentence identifying the evidence. A set of requests can score well for fit while scoring poorly for variety; keep the dimensions distinct. A generic refusal such as “no” is relevant without an explicit preference quote. A card offering “glue” is not itself an assertion that Noor likes glue. “I love sticky glue” directly contradicts the supplied preference and is a material mismatch. Do not require every card to be personalized or treat short vocabulary as inferior to sentences. When a rating is uncertain, record the ambiguity for calibration rather than inventing a person-specific rule.

## Secondary dimensions

- **Unsupported/incompatible cards:** count cards that assert unprovided personal facts, contradict explicit case facts, or concern unavailable context without a plausible communicative purpose. Explain each flagged card. This is not a count of new wording or unmentioned general vocabulary.
- **Distinct functions, 0–5:** count represented categories among requesting/action, refusing/stopping/disagreeing, commenting/sharing information, asking a question, and social connection. A card can serve multiple functions when a reasonable use is described. “Look at this!” can comment and invite shared attention. These categories are working definitions, not an exhaustive taxonomy.
- **Redundant cards:** count excess cards in semantic clusters with no meaningful difference for this activity. “Water” and “more water” may serve different purposes and should not automatically be counted as duplicates. Record the cluster and reason.
- Record card count for interpretation, without awarding points for quantity.

## Calibration examples: planting case

These are constructed illustrations, not gold-standard AAC sets or study results. Do not give them to participants.

| Example set | Illustrative reasoning |
|---|---|
| “I want seeds”; “Give me water”; “More water”; “Give me the pot”; “I love touching wet soil”; “The television is loud” | Provisional fit 1–2: relevant requests coexist with a contradicted preference and an unsupported context. The exact fit score requires rater calibration. Requesting and commenting are represented, even though some comments are inappropriate. |
| “Sunflower seeds”; “Use the scoop”; “No wet soil”; “Look at this!”; “Your turn”; “Stop” | Provisional fit 4: reflects available materials and context without presuming participation. Several functions are plausible. This is only one possible set; do not reward matching its wording. |
| “Seeds”; “Water”; “Pot”; “Scoop” | Provisional fit 3–4 depending on the agreed interpretation: usable activity vocabulary, limited function variety. A low variety count must not silently lower fit. |
| “Sunflowers are my favorite”; “I always want to garden” | Provisional fit 1–2: the second asserts stable intent not supplied in the case. Matching the interest does not repair that assertion. |

Before freezing the rubric, two qualified raters should score separate constructed calibration sets independently, discuss disagreements and sharpen these anchors. They should document language/cultural expertise and the limits of rating short phrases outside actual interaction. If reliable application proves difficult, redesign the instrument rather than collecting more weak scores.

## Blinding and aggregation

Give raters only the rating packets, this rubric and blank worksheets. Mix sets across sessions in randomized order. Session JSON contains condition and timing and must remain with the coordinator. App packets omit condition, prompt checks, starter cards, time, effort and participant/session identifiers. Final wording and repeated profile details can still permit inferences: call this masked condition metadata, not guaranteed blinding.

Use separate rater codes. Independently score every set before discussion. Retain both original ratings. Primary analysis averages the two original fit scores within each task and then averages the two tasks for each adult. Report exact fit-score agreement and the distribution of absolute rater differences before any reconciliation. Disagreements are information about the instrument; do not replace them with consensus scores after seeing condition results.

The downloaded CSV has columns `artifact_id,rater_code,scenario_fit_0_4,unsupported_cards,distinct_functions_0_5,redundant_cards,rationale`. One row is one rater's judgment of one set. Duplicate the blank worksheet for the second rater. Raters should not receive the calibration examples used to construct participant starter cards as a hidden answer key; finalize a separate calibration set with the mentor.
