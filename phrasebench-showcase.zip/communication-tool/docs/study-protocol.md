# Study protocol for mentor review

Draft 0.1.0 · 7 September 2026 · Not an approved protocol

## Design and scope

Adult-only, randomized parallel-group feasibility study of an ordinary text-card editor versus the identical editor with three personalization-review prompts. Each adult completes planting and collage tasks. Two activity orders are balanced within each condition. No children participate, no real child records are used, and materials are not deployed as communication interventions.

The original brief suggested a within-person comparison. We changed this because reading the review prompts can teach a strategy that transfers into a later control task. Parallel allocation avoids this carryover; increased between-person variation is the tradeoff. We are testing the availability of a review panel, not isolating checklist wording from extra attention or reading time. An attention-matched control is a possible later experiment.

## Population, sample and allocation

Proposed population: adults who currently prepare communication materials in one defined educational/support setting and can work with the English fictional cases using the supplied text editor. A mentor must verify that this population is available and appropriate. Do not replace it with classmates and retain staff-level claims. Record prior preparation experience in broad bands chosen before recruitment; no employment performance evaluation.

Planning target: 16 completed sessions across four cells (ordinary/planting-first, ordinary/collage-first, review/planting-first, review/collage-first), four per cell. This is a resource-based pilot target, not a powered test of efficacy. Proposed recruitment ceiling 20 enrolled adults; report all withdrawals and incompletes, and stop at the earlier of 16 completions or that ceiling. The mentor must approve or revise both numbers before recruitment. Do not extend recruitment after looking at group outcomes.

After approval, the coordinator generates a randomized sequence in blocks of four, containing one entry for each cell. Keep future assignments concealed until each participant is enrolled. Assign people by that sequence, not by preference, experience or known performance. Log deviations; do not silently swap assignments to balance completion counts. The demo's selectors support rehearsal of all cells but are not a randomization system.

## Readiness conditions

Before recruitment: identify the supervising mentor, institution, intended submission route and applicable review requirements; obtain required approvals and informed consent materials; finalize eligibility, sample, prompts, cases and rubric; confirm two qualified raters; freeze app/material versions and archive checksums; document a data retention/deletion plan and who can access records. The present release is a demo and explicitly marks exports as demonstration. A study release must be reviewed and versioned after approval, including a random study-code workflow; do not relabel existing demo files as research data.

For an ISEF-affiliated project, the official [Human Participants rules](https://www.societyforscience.org/isef/international-rules/human-participants/) include prototype testing with other people and prior review requirements. Institutional rules and jurisdiction are not yet known. This paragraph is a planning dependency, not a substitute for the relevant review body.

## Session procedure

1. Follow the approved consent procedure. Explain voluntariness, withdrawal, planned records and separation from employment evaluation. Use an assigned study code; do not type names, email addresses or real child information into the editor.
2. Use a common device/browser/viewport where practical. Record departures that could affect time or access. Demonstrate adding, editing and removing a neutral card in a separate practice instance using “hello” and “goodbye,” without discussing review strategies, study cases or scoring criteria. Close that instance before the timed session. Offer equivalent technical support in both groups.
3. Coordinator loads the assigned version and order before handing over the device. Both groups receive this instruction: “Prepare a small supplemental set of useful words or short phrases for this activity. Edit, add, or remove the starter cards as you judge appropriate. The set supplements the person's existing communication system.” Do not suggest card counts or desired functions beyond what the assigned interface displays.
4. Open the workspace. Timing begins when the case and cards appear; it includes reading the case and, when present, review prompts. The adult can edit freely and finish when ready. Review checkboxes are optional and cannot prevent completion.
5. Allow pauses at any time. The pause button hides task content and excludes that interval from active time. Record interruptions and technical help in a separate structured deviation log; do not coach content. No imposed time cap is included in this draft; if a session runs beyond the agreed appointment, offer stopping without penalty and record an incomplete task.
6. After Finish, timing stops. Offer the identical optional effort scale and comment field in both groups. Open the second activity in the same editor version. A break before opening it is outside task timing.
7. After both activities, export the session, rating packet and worksheet. Verify that files open and that two artifact IDs map to the assigned study code in a separate coordinator file. Never send session files to raters. Conclude using the approved debrief, without presenting the participant's work as clinical advice.

Practical scheduling estimate: 25–35 minutes, to be revised after authorized feasibility work. No human timing observations currently support it.

## Records, deviations and withdrawal

The current prototype holds work only in memory until download; refresh/closing can lose it. A before-unload prompt reduces accidental loss but is not recovery. In-progress/withdrawn tasks do not produce a completed-session export. In the eventual study, record enrollment, assigned cell, incomplete status, reason if voluntarily supplied, technical failures and withdrawal requests in a separate coordinator log. Do not infer absence of withdrawals from exported completed sessions.

For a withdrawn participant, follow the approved data-removal request process, including any constraints after irreversible anonymization; define that point in consent before enrollment. Store consent separately from task data. Restrict raw session and mapping access to the authorized coordinator/mentor. Raters receive masked packets only. Do not publish raw comments without reviewing them for accidentally identifying content. Retention duration, storage location and deletion responsibility must be set by the mentor/institution before collection.

## Outcomes and analysis fixed before data collection

Primary endpoint is the adult-level average scenario-fit score from the two cases, with two independent raters per case. Average raters within a case, then the two cases within adult. Primary contrast is review group mean minus ordinary group mean. The primary complete-case estimate includes adults with both completed tasks and both fit ratings. Report excluded/missing cases and denominators by assigned group. Do not impute missing fit scores as zero. A sensitivity table may show available-task averages, explicitly labeled and not substituted for the primary endpoint.

Report adult-level raw scores, group means/SDs and medians/ranges, the mean difference, and a 95% bootstrap interval resampling adults within condition (10,000 replicates, fixed recorded seed). With small samples and a coarse ordinal score, intervals can be unstable; display individual scores and avoid interpreting a zero-crossing interval as equivalence. Describe this as exploratory feasibility, not a definitive superiority test. No repeated phrases or task records count as independent participants.

Secondary endpoints: mean active seconds per adult, mean wall seconds, effort ratings with their own nonmissing denominator, unsupported-card counts, function counts, redundancy and editing counts. Report each separately and avoid selectively promoting a favorable secondary endpoint to the main result. Summarize order and prior-experience patterns descriptively; this pilot is not sized for reliable subgroup effects. Checklist completion describes use of the intervention, not a validated mediator or fidelity measure.

Agree with the mentor on a meaningful fit difference and acceptable preparation-time burden before collecting outcomes; no validated thresholds are available for our draft rubric. A positive estimate with imprecision can justify refinement, not a child-benefit claim. Unchanged fit with longer time, more unsupported assertions, or poor rater agreement are reasons to reconsider the design. Any confirmatory follow-up needs a new justified sample plan.

## Threats to interpretation

Cases and starter errors are constructed and deliberately noticeable. This can overstate usefulness relative to ordinary work. Two cases share a template; they are not independent evidence of broad transfer. Text cards omit photos, symbols, hotspots, access methods, multilingual work and actual interaction. Adults cannot be blinded to prompts; demand effects and attention differences remain. The checklist partially overlaps scoring constructs. Raters should assess usability against context rather than count checklist phrases. Condition masking can fail through output wording. Real child preference and communication benefit remain unmeasured.
