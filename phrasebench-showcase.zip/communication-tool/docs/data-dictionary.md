# Demo exports and measures

The authoritative fixture definitions are in `scenarios.js`. The app version and fixture version are 0.1.0. All records produced now are demonstration records. No model is called, no account is used, no remote collection endpoint exists, and no browser storage is used by the app.

## Session JSON

- `schemaVersion`, `mode`: format version and `demonstration` label.
- `sessionId`: randomly generated identifier, not a participant identity or enrollment code.
- `condition`: `standard` or `review`; `order`: scenario IDs in task order.
- `suggestionSource`: fixed, hand-authored examples.
- `tasks`: one completed record per activity. `artifactId` links a set to its masked rating packet. `scenarioId` and `position` identify case and presentation position. `cards` contains final trimmed text.
- `activeSeconds`: monotonic elapsed task time minus explicit pauses; includes case reading, review reading, and time in another tab unless explicitly paused. Rounded to hundredths of a second for arithmetic, not a claim of behavioral measurement precision.
- `wallSeconds`: all elapsed time from case opening to Finish, including pauses. `pausedSeconds` and `pauseCount`: explicit pause duration and number.
- `hiddenSeconds`: total time the document was hidden while the task was active or paused; overlaps other time measures and must not be subtracted again. A visible tab is not proof of attention.
- `editCommits`: changed input values committed by blur/change events; not keystrokes, distinct edited cards, or semantic edit quality. `additions`, `removals`: card actions including later-undone actions.
- `reviewChecks`: three final booleans for the review version, otherwise null. The app does not force checks or record reading.
- `effort`: optional integer 1–5 (very little to very much), null if skipped. This single draft item is not NASA-TLX or another validated scale.
- `note`: optional fictional-case comment. No real personal information should be entered.

Reflection time and between-task breaks are outside preparation time. The app does not retain keystroke logs, raw audio or photographs. It does not compute relevance or infer communicative intent.

## Rating packet JSON and worksheet CSV

The packet contains schema/mode, instructions, randomized set IDs, final cards and the corresponding fictional case. It omits session ID, condition, task order, original suggestions, checklist, timing, edits, effort and comments. Within a packet, sets are sorted by random IDs; the coordinator must mix all participants' sets before rating to reduce session grouping clues. Scenario IDs are necessary to interpret the materials and remain visible.

The worksheet exports anonymous artifact IDs and empty rater fields. Raw card text is not exported to CSV, avoiding accidental spreadsheet formulas in that file. JSON safely preserves punctuation and Unicode. The session file supplies the mapping to condition; restrict it to the coordinator.

The current app is not an enrollment, consent, secure study-storage or statistical-analysis system. Those responsibilities and the future analysis are specified in the protocol. Local downloads are ordinary files and must be handled according to the eventual approved data plan.
