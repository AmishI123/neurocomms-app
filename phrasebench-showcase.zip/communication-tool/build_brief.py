"""Render the proposal's headings/paragraphs/inline links to standalone HTML."""
from pathlib import Path
import html
import re
root = Path(__file__).resolve().parent
source = (root / 'docs/mentor-brief.md').read_text()
def inline(value):
    value = html.escape(value)
    value = re.sub(r'\[([^\]]+)\]\(([^)]+)\)', r'<a href="\2">\1</a>', value)
    return re.sub(r'\*\*(.+?)\*\*', r'<strong>\1</strong>', value)
parts = []
for block in source.strip().split('\n\n'):
    if block.startswith('# '): parts.append('<h1>' + inline(block[2:]) + '</h1>')
    elif block.startswith('## '): parts.append('<h2>' + inline(block[3:]) + '</h2>')
    else: parts.append('<p>' + inline(block.replace('\n', ' ')) + '</p>')
style = '''body{max-width:820px;margin:50px auto;padding:0 26px;color:#203a34;font:16px/1.6 system-ui,sans-serif;background:#f6f4ed}h1{font:40px/1.14 Georgia,serif}h2{font-size:22px;margin-top:32px;break-after:avoid}a{color:#245648}p{orphans:3;widows:3}nav{font-size:14px;margin-bottom:35px}@media print{body{background:white;margin:0;padding:0;font-size:10.5pt;line-height:1.45}h1{font-size:25pt}h2{font-size:14pt;margin-top:18px}nav{display:none}@page{size:A4;margin:18mm}}'''
(root / 'docs/mentor-brief.html').write_text('<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Phrase Studio · Mentor proposal</title><style>'+style+'</style><nav><a href="../index.html">← Open the demo</a></nav><main>'+''.join(parts)+'</main></html>')
print('Created docs/mentor-brief.html')
