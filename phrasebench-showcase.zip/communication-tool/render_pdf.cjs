const {chromium}=require('playwright');
const path=require('node:path');
(async()=>{
  const browser=await chromium.launch({headless:true,executablePath:process.env.CHROMIUM_PATH||undefined,args:['--no-sandbox']});
  try{
    const page=await browser.newPage();
    await page.goto('file://'+path.join(__dirname,'docs/mentor-brief.html'));
    await page.evaluate(()=>document.querySelectorAll('a[href]').forEach(a=>{if(!a.getAttribute('href').startsWith('https://'))a.replaceWith(document.createTextNode(a.textContent));}));
    await page.pdf({path:path.join(__dirname,'docs/mentor-brief.pdf'),format:'A4',printBackground:true,preferCSSPageSize:true});
    console.log('Created docs/mentor-brief.pdf with external source links. Local document references are plain text.');
  }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
