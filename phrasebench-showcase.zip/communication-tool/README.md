# Phrase Studio

A working local prototype and mentor-review package for testing a personalization review step in adult preparation of supplemental communication materials.

## Open the demo

Open **index.html** in a desktop browser, or run from this directory:

```bash
python3 -m http.server 8765 --bind 127.0.0.1
```

Then visit **http://localhost:8765**. No runtime installation, account or API key is needed. The demo also works directly from a file URL.

Select an editor version and activity order. Edit cards, try adding/removing a card, and finish each of the two fictional activities. The review version adds three optional reflection prompts. Pause hides the activity and stops active time. At the end, download the session JSON, masked rating packet and blank rating worksheet. Download before leaving: work is held in this tab only.

All exports are labeled demonstration. The starter suggestions are hand-written and intentionally imperfect. This is an adult authoring experiment; materials are supplemental and not a clinical communication system.

## Read the package

- [Mentor proposal](docs/mentor-brief.html) · [Markdown source](docs/mentor-brief.md)
- [Focused evidence and competing work](docs/evidence-check.md)
- [Draft study protocol](docs/study-protocol.md)
- [Scoring rubric and calibration examples](docs/scoring-rubric.md)
- [Data dictionary](docs/data-dictionary.md)
- [Constructed example outputs](examples/worked-materials.md)
- [Verification](qa/verification.md)

The proposed study randomly assigns each adult to one editor version, with activity order balanced within groups. This avoids review strategies carrying into a later ordinary-editor task. The selector is for demonstration; actual allocation is a coordinator responsibility after review. No participants have been recruited or studied.

## Files and verification

`index.html`, `style.css`, `app.js` and `scenarios.js` make up the app. There are no runtime dependencies or external fonts. `package-lock.json` pins the development browser-testing dependency.

```bash
npm ci
npx playwright install chromium
npm test
```

Browser tests launch their own local server on an available port. On Linux, Playwright's documented browser system dependencies must be available. If using an existing browser, set `CHROMIUM_PATH` to its executable. The workspace verification used the cached Chromium executable and local browser libraries; see `qa/verification.md` for the exact command.

Tests cover both versions and task orders, editing, pause timing, validation, optional reflection/checks, exports and masking, mobile layout, no external requests, and safe literal text rendering. Screenshots are saved in `qa/`. Automated runs generate demonstration data, not human usability evidence.

## Current limits

Two English text-only cases; unvalidated rubric and effort item; no live AI, child testing, autosave or study enrollment. The app and documents are ready for a mentor discussion. Participant recruitment, approved study configuration and real data collection are the following phase.
