/* Original fictional materials, version 0.1.0. No real child records. */
window.CASES = [
  {
    id: 'garden', title: 'Planting with a friend', activity: 'A shared planting activity',
    person: 'Ari', age: 9,
    profile: 'Ari enjoys sunflowers and sharing discoveries with a friend. Ari uses familiar words and short phrases on an existing communication system. That full system stays available throughout the activity.',
    context: 'Ari and a friend can choose sunflower or bean seeds, fill a pot with soil, and water it. Both seed types, pots, soil, water, and a scoop are available. Ari can watch, join in, change activities, or leave.',
    preferences: 'Ari has said “sunflowers” and “no wet soil.” A scoop is available for handling soil. Do not assume that Ari wants to touch soil or participate today.',
    brief: 'Prepare a small supplemental set of useful words or short phrases for this activity. Edit, add, or remove the starter cards as you judge appropriate. The set supplements the person’s existing communication system.',
    starters: ['I want seeds', 'Give me water', 'More water', 'Give me the pot', 'I love touching wet soil', 'The television is loud'],
    checks: ['Does the set fit the activity and Ari’s stated preferences, without assuming what Ari wants today?', 'Does the set leave room to comment, connect with someone, disagree, or stop, as well as request things?', 'Are any cards repetitive, unsupported by the scenario, or better expressed another way? Keep useful general words too.']
  },
  {
    id: 'art', title: 'Making a shared collage', activity: 'A shared collage activity',
    person: 'Noor', age: 9,
    profile: 'Noor enjoys pictures of trains and sharing discoveries with a friend. Noor uses familiar words and short phrases on an existing communication system. That full system stays available throughout the activity.',
    context: 'Noor and a friend can choose train or animal pictures, arrange them on paper, and attach them. Both picture types, paper, glue, removable tape, and a tray are available. Noor can watch, join in, change activities, or leave.',
    preferences: 'Noor has said “trains” and “no sticky glue.” Removable tape is available for attaching pictures. Do not assume that Noor wants to touch glue or participate today.',
    brief: 'Prepare a small supplemental set of useful words or short phrases for this activity. Edit, add, or remove the starter cards as you judge appropriate. The set supplements the person’s existing communication system.',
    starters: ['I want pictures', 'Give me glue', 'More glue', 'Give me the paper', 'I love sticky glue', 'The television is loud'],
    checks: ['Does the set fit the activity and Noor’s stated preferences, without assuming what Noor wants today?', 'Does the set leave room to comment, connect with someone, disagree, or stop, as well as request things?', 'Are any cards repetitive, unsupported by the scenario, or better expressed another way? Keep useful general words too.']
  }
];
