'use strict';
const $ = id => document.getElementById(id);
const VERSION = '0.1.0';
let session = null, task = null, index = 0, clock = null;
const uid = () => 'set-' + (globalThis.crypto?.randomUUID?.() || `${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`);
const seconds = ms => Math.round(ms / 1000 * 100) / 100;
function announce(message) { $('announcement').textContent = message; }
function screen(name) {
  ['setup','workspace','reflection','complete'].forEach(id => $(id).hidden = id !== name);
  $('main').focus(); window.scrollTo(0, 0);
}
function elapsed(now = performance.now()) {
  if (!task) return 0;
  return (task.ended ?? now) - task.started - task.pausedMs - (task.pauseStart === null ? 0 : now - task.pauseStart);
}
function updateTimer() {
  const s = Math.floor(elapsed() / 1000);
  $('timer').textContent = `${String(Math.floor(s / 60)).padStart(2,'0')}:${String(s % 60).padStart(2,'0')}`;
}
function makeCard(value, cardId = uid()) {
  const row = document.createElement('div'); row.className = 'card-row'; row.dataset.id = cardId;
  const number = document.createElement('label'); number.className = 'card-number'; number.htmlFor = cardId;
  const input = document.createElement('input'); input.type = 'text'; input.id = cardId; input.value = value; input.maxLength = 160; input.autocomplete = 'off';
  let previous = value;
  input.addEventListener('change', () => { if (input.value !== previous) { task.edits++; previous = input.value; } });
  const remove = document.createElement('button'); remove.className = 'remove'; remove.textContent = '×'; remove.type = 'button';
  remove.addEventListener('click', () => { const next = row.nextElementSibling || row.previousElementSibling; row.remove(); task.removals++; renumber(); (next?.querySelector('input') || $('add')).focus(); announce('Card removed.'); });
  row.append(number,input,remove); $('cards').append(row); renumber(); return input;
}
function renumber() {
  [...$('cards').children].forEach((row,i) => { row.querySelector('label').textContent = String(i+1).padStart(2,'0'); row.querySelector('input').setAttribute('aria-label',`Phrase card ${i+1}`); row.querySelector('button').setAttribute('aria-label',`Remove card ${i+1}`); });
  $('count').textContent = `${$('cards').children.length} cards`;
}
function beginTask() {
  const scenario = CASES.find(s => s.id === session.order[index]);
  task = {scenario,artifactId:uid(),started:performance.now(),ended:null,pausedMs:0,pauseStart:null,pauses:0,hiddenStart:null,hiddenMs:0,edits:0,additions:0,removals:0};
  $('step').textContent = `ACTIVITY ${index + 1} OF 2`;
  $('case-title').textContent = scenario.title;
  $('person').textContent = `${scenario.person}, ${scenario.age}`;
  for (const key of ['profile','context','preferences','brief']) $(key).textContent = scenario[key];
  $('version').textContent = session.condition === 'review' ? 'Editor + review' : 'Ordinary editor';
  $('cards').replaceChildren(); scenario.starters.forEach(value => makeCard(value));
  $('checks').replaceChildren();
  scenario.checks.forEach((message,i) => {
    const label = document.createElement('label'); label.className = 'check';
    const check = document.createElement('input'); check.type = 'checkbox'; check.id = `check-${i}`;
    const text = document.createElement('span'); text.textContent = message; label.append(check,text); $('checks').append(label);
  });
  $('review-panel').hidden = session.condition !== 'review';
  $('work-content').hidden = false; $('pause-message').hidden = true; $('pause').textContent = 'Pause'; $('error').textContent = '';
  screen('workspace'); updateTimer(); clock = setInterval(updateTimer,250);
}
$('start').addEventListener('click', () => {
  session = {schemaVersion:VERSION,mode:'demonstration',sessionId:uid(),condition:document.querySelector('[name=condition]:checked').value,order:$('order').value.split(','),suggestionSource:'Fixed, hand-authored fictional examples; no AI generation',tasks:[]};
  index = 0; beginTask();
});
$('add').addEventListener('click', () => { task.additions++; makeCard('').focus(); announce('New card added.'); });
$('pause').addEventListener('click', () => {
  if (task.pauseStart === null) { task.pauseStart = performance.now(); task.pauses++; $('pause').textContent = 'Resume'; $('work-content').hidden = true; $('pause-message').hidden = false; }
  else { task.pausedMs += performance.now() - task.pauseStart; task.pauseStart = null; $('pause').textContent = 'Pause'; $('work-content').hidden = false; $('pause-message').hidden = true; }
  updateTimer();
});
document.addEventListener('visibilitychange', () => {
  if (!task || task.ended !== null) return;
  if (document.hidden && task.hiddenStart === null) task.hiddenStart = performance.now();
  if (!document.hidden && task.hiddenStart !== null) { task.hiddenMs += performance.now() - task.hiddenStart; task.hiddenStart = null; }
});
$('finish').addEventListener('click', () => {
  if (task.pauseStart !== null) return;
  const inputs = [...$('cards').querySelectorAll('input')];
  if (!inputs.length || inputs.some(input => !input.value.trim())) {
    $('error').textContent = inputs.length ? 'Fill in or remove empty cards before finishing.' : 'Add at least one card before finishing. You can also stop by closing this demo.';
    (inputs.find(input => !input.value.trim()) || $('add')).focus(); return;
  }
  task.ended = performance.now();
  if (task.hiddenStart !== null) { task.hiddenMs += task.ended - task.hiddenStart; task.hiddenStart = null; }
  clearInterval(clock); updateTimer();
  task.result = {artifactId:task.artifactId,scenarioId:task.scenario.id,position:index+1,cards:inputs.map(input=>input.value.trim()),activeSeconds:seconds(elapsed()),wallSeconds:seconds(task.ended-task.started),pausedSeconds:seconds(task.pausedMs),pauseCount:task.pauses,hiddenSeconds:seconds(task.hiddenMs),editCommits:task.edits,additions:task.additions,removals:task.removals,reviewChecks:session.condition==='review'?[...$('checks').querySelectorAll('input')].map(c=>c.checked):null};
  $('effort').value = ''; $('note').value = ''; $('continue').textContent = index === 0 ? 'Open next activity →' : 'View finished materials →'; screen('reflection');
});
$('continue').addEventListener('click', () => {
  task.result.effort = $('effort').value ? Number($('effort').value) : null;
  task.result.note = $('note').value.trim(); session.tasks.push(task.result); index++;
  if (index < session.order.length) beginTask(); else complete();
});
function complete() {
  $('summary').replaceChildren();
  for (const result of session.tasks) {
    const panel = document.createElement('article'); panel.className = 'panel';
    const title = document.createElement('h2'); title.textContent = CASES.find(s=>s.id===result.scenarioId).title;
    const meta = document.createElement('p'); meta.className = 'quiet'; meta.textContent = `${result.cards.length} cards · ${result.activeSeconds.toFixed(1)} seconds active preparation`;
    const list = document.createElement('ul'); result.cards.forEach(value=>{const item=document.createElement('li');item.textContent=value;list.append(item);});
    panel.append(title,meta,list); $('summary').append(panel);
  }
  screen('complete');
}
function download(name, content, type) {
  const url = URL.createObjectURL(new Blob([content],{type})); const a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000); announce('Download prepared.');
}
function ratingPacket() {
  return {schemaVersion:VERSION,mode:'demonstration',instructions:'Rate against the separate draft rubric. Condition and timing are intentionally omitted. Keep this packet separate from session files.',sets:session.tasks.map(t=>{const s=CASES.find(s=>s.id===t.scenarioId);return {artifactId:t.artifactId,scenario:{id:s.id,title:s.title,person:s.person,age:s.age,profile:s.profile,context:s.context,preferences:s.preferences,brief:s.brief},cards:t.cards};}).sort((a,b)=>a.artifactId.localeCompare(b.artifactId))};
}
$('download-session').addEventListener('click',()=>download(`demo-session-${session.sessionId}.json`,JSON.stringify(session,null,2),'application/json'));
$('download-rating').addEventListener('click',()=>download('demo-rating-packet.json',JSON.stringify(ratingPacket(),null,2),'application/json'));
$('download-csv').addEventListener('click',()=>{
  const headers=['artifact_id','rater_code','scenario_fit_0_4','unsupported_cards','distinct_functions_0_5','redundant_cards','rationale'];
  const rows=ratingPacket().sets.map(s=>[s.artifactId,'','','','','',''].join(','));
  download('demo-rating-worksheet.csv',[headers.join(','),...rows].join('\r\n')+'\r\n','text/csv');
});
$('restart').addEventListener('click',()=>{session=null;task=null;index=0;screen('setup');});
window.addEventListener('beforeunload', e=>{if(session){e.preventDefault();e.returnValue='';}});
