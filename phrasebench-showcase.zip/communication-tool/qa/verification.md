# Verification and completion audit

7 September 2026 · Phrase Studio v0.1.0

## Scope

The user authorized the proposed end-to-end milestone: focused gap check, concrete experiment, both editor versions, fictional scenarios and workflow checks, and a package for mentor review. The deliverable is a working demonstrator and reviewable study design. It does not include mentor approval, recruitment, a real study, a validated rubric or evidence of child benefit.

| Requirement | Authoritative evidence |
|---|---|
| Exact gap and competing tools checked | docs/evidence-check.md records primary-source links, inspected sections, search terms, nearby 2026 work, direct-fetch limits and a bounded contribution claim. |
| Experiment specified | docs/study-protocol.md defines population, provisional sample/ceiling, parallel allocation, balanced case order, procedure, outcomes, adult-level analysis, missingness and threats. docs/scoring-rubric.md supplies score anchors and examples. |
| Both working editors | app.js and index.html use the same scenario fixtures and controls. Browser tests complete all four condition/order combinations and compare identical starter values across conditions. |
| Fictional scenarios and materials | scenarios.js contains two original cases with context, stated preferences and six fixed suggestions. examples/worked-materials.md provides constructed alternatives; automated example exports are explicitly labeled demonstration. |
| Editing and completion | Tests exercise edits, addition, removal, blank/zero-card validation, optional checks and skipped reflection, both task transitions and restart. |
| Timing and export correctness | Tests verify pause freezes the display/hides content, paused duration is retained, active + pause equals wall time within rounding, action counts and effort values export, cards preserve Unicode/literal markup, and three downloads are readable. |
| Rater masking | Tests recursively reject condition, session ID, order-position, prompt checks, timing, starters and reflection fields from rating packets; IDs and final text match raw sessions. This masks metadata, not all inferable condition cues. |
| Local operation | Tests open via local HTTP and directly via file URL, observe no remote requests during the workflow and confirm no local/session storage is used. |
| Layout | Saved desktop setup, standard/review editor and completed screens, plus mobile screens. Visual inspection of setup, review editor and completion found no overlapping controls. Mobile test verifies no page-width overflow at 390px. Long single-line card inputs scroll within their field. |
| Mentor proposal | docs/mentor-brief.html renders; docs/mentor-brief.pdf is two pages. Both PDF pages were visually inspected. qa/pdf-check.json records text-bounds and replacement-glyph checks and external citation URLs. Local cross-document links are plain text in the PDF to avoid dead localhost URLs; HTML retains navigation. |
| Recoverable handoff | README.md, parent PROJECT-CONTEXT.md and PROJECT-A-PLAN.md describe the current milestone, file locations and next phase. |

## Execution evidence

`qa/test-results.txt` records seven passing tests (six subtests plus the parent workflow), zero failures. Browser: cached Chromium 151.0.7922.34, controlled by pinned Playwright 1.58.2. Actual command in this workspace:

```bash
CHROMIUM_PATH=/home/mehta/.cache/ms-playwright/chromium-1234/chrome-linux64/chrome LD_LIBRARY_PATH=/home/mehta/.cache/sdl-browser-libs/usr/lib/x86_64-linux-gnu npm test
```

The initial browser launch found missing system libraries; an existing local browser-library directory supplied them without modifying system packages. The final workflow tests passed. After visual review, completion-screen spacing was adjusted and the final browser suite rerun. The Unicode fixture uses accented Latin text supported by this environment's fonts. Other scripts retain their characters in JSON, but visual rendering depends on installed fonts and was not comprehensively tested.

To regenerate the proposal: `python3 build_brief.py`, then `node render_pdf.cjs` with an available Playwright browser (or the same environment overrides). The PDF builder strips local document navigation links while preserving external source citations.

## Limits of verification

These are automated software checks and researcher inspection, not human usability or efficacy evidence. No screen-reader audit or exhaustive browser/device compatibility evaluation was performed. Document-hidden timing has an implemented event handler but was not directly simulated in the browser tests; active preparation time does not measure attention. No automatic semantic scoring, enrollment, autosave, participant identity mapping or inferential-analysis program is claimed. The draft protocol explicitly defines responsibilities for a later approved study release.

The closest-paper comparison and 2026 follow-up support scoping this interface experiment; they do not certify global novelty. The rubric needs specialist review and calibration, and the sample proposal needs mentor review. Those are explicit next-phase decisions, not represented as completed here.
