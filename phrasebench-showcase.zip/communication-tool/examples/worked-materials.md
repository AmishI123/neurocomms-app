# Constructed example materials

These are authored illustrations, not observations, recommended child vocabularies or experimental results. Many other outputs could fit. Real communication intent cannot be inferred from a fictional profile.

| Case | Fixed starter set | One possible edited set |
|---|---|---|
| Planting | I want seeds; Give me water; More water; Give me the pot; I love touching wet soil; The television is loud | Sunflower seeds; Use the scoop; No wet soil; Look at this!; Your turn; Stop |
| Collage | I want pictures; Give me glue; More glue; Give me the paper; I love sticky glue; The television is loud | Train pictures; Tape please; No glue; Look at this!; Your turn; Stop |

Each alternative uses the supplied activity and personal context while retaining room to refuse or share attention. That is a design rationale, not a validated score. The rubric separately rates fit and variety, so copying these phrases is not the task or a success criterion. The starter sets are identical across editor conditions; an ordinary-editor user can make every change shown here.

`example-session.json` and `example-rating-packet.json`, generated during automated verification, demonstrate the export format. Their measured times reflect browser automation and must not be used to estimate human preparation time. The scripted changes are only test actions and do not model participant behavior or an intervention effect.
