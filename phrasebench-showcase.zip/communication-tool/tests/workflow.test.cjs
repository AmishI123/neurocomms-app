const {test} = require('node:test');
const assert = require('node:assert/strict');
const {chromium} = require('playwright');
const fs = require('node:fs/promises');
const path = require('node:path');
const http = require('node:http');
const root = path.resolve(__dirname,'..');
const sleep = ms => new Promise(r=>setTimeout(r,ms));

test('Complete both editor versions, both orders, and verify research exports', {timeout:180000}, async t => {
  const server=http.createServer(async(req,res)=>{
    try {
      const name=decodeURIComponent(new URL(req.url,'http://localhost').pathname);
      const file=path.resolve(root,'.'+(name==='/'?'/index.html':name));
      if(!file.startsWith(root+path.sep)){res.writeHead(403);res.end();return;}
      const data=await fs.readFile(file);
      const types={'.html':'text/html','.js':'text/javascript','.css':'text/css','.md':'text/plain'};
      res.setHeader('Content-Type',types[path.extname(file)]||'application/octet-stream');res.end(data);
    }catch{res.writeHead(404);res.end();}
  });
  await new Promise(r=>server.listen(0,'127.0.0.1',r));
  t.after(()=>new Promise(r=>server.close(r)));
  const base=`http://127.0.0.1:${server.address().port}`;
  const browser=await chromium.launch({headless:true,executablePath:process.env.CHROMIUM_PATH||undefined,args:['--no-sandbox']});
  t.after(()=>browser.close());
  const baselines={};
  for(const condition of ['standard','review'])for(const order of ['garden,art','art,garden']){
    await t.test(`${condition}, ${order}`,async()=>{
      const context=await browser.newContext({viewport:{width:1365,height:1000},acceptDownloads:true});
      const page=await context.newPage();const errors=[],remote=[];
      page.on('pageerror',e=>errors.push(String(e)));page.on('request',r=>{if(!r.url().startsWith(base))remote.push(r.url());});
      await page.goto(base);
      if(condition==='standard'&&order==='garden,art')await page.screenshot({path:path.join(root,'qa/setup-desktop.png'),fullPage:true});
      await page.check(`[name=condition][value=${condition}]`);await page.selectOption('#order',order);await page.click('#start');
      const ordered=order.split(',');
      for(let i=0;i<2;i++){
        assert.equal(await page.locator('#step').textContent(),`ACTIVITY ${i+1} OF 2`);
        assert.equal(await page.locator('#review-panel').isVisible(),condition==='review');
        const starters=await page.locator('#cards input').evaluateAll(xs=>xs.map(x=>x.value));
        if(condition==='standard')baselines[ordered[i]]=starters;else assert.deepEqual(starters,baselines[ordered[i]]);
        assert.equal(starters.length,6);
        if(i===0){
          await page.click('#pause');assert.equal(await page.locator('#work-content').isVisible(),false);
          const before=await page.locator('#timer').textContent();await sleep(1100);assert.equal(await page.locator('#timer').textContent(),before);await page.click('#pause');
          if(condition==='review'&&order==='garden,art')await page.screenshot({path:path.join(root,'qa/editor-review-desktop.png'),fullPage:true});
          if(condition==='standard'&&order==='garden,art')await page.screenshot({path:path.join(root,'qa/editor-standard-desktop.png'),fullPage:true});
        }
        const literal='Look <here> & say “café”';
        await page.locator('#cards input').first().fill(literal);
        await page.click('#add');await page.click('#finish');assert.equal(await page.locator('#error').textContent(),'Fill in or remove empty cards before finishing.');
        await page.locator('#cards input').last().fill('Stop');
        await page.getByRole('button',{name:'Remove card 6',exact:true}).click();
        assert.equal(await page.locator('#cards input').count(),6);
        if(condition==='review'&&i===0)await page.locator('#check-0').check();
        await page.click('#finish');assert.equal(await page.locator('#reflection').isVisible(),true);
        if(i===0){await page.selectOption('#effort','3');await page.fill('#note','Automated demo only.');}
        await page.click('#continue');
      }
      assert.equal(await page.locator('#complete').isVisible(),true);
      async function downloaded(selector){const event=page.waitForEvent('download');await page.click(selector);const d=await event;return fs.readFile(await d.path(),'utf8');}
      const raw=JSON.parse(await downloaded('#download-session'));
      const packet=JSON.parse(await downloaded('#download-rating'));
      const csv=await downloaded('#download-csv');
      assert.equal(raw.mode,'demonstration');assert.equal(raw.condition,condition);assert.deepEqual(raw.order,ordered);assert.equal(raw.tasks.length,2);
      for(const [i,result] of raw.tasks.entries()){
        assert.equal(result.cards[0],'Look <here> & say “café”');assert.equal(result.cards.length,6);
        assert.ok(result.editCommits>=2);assert.equal(result.additions,1);assert.equal(result.removals,1);
        assert.ok(Math.abs(result.wallSeconds-result.activeSeconds-result.pausedSeconds)<0.031);
        assert.equal(result.pauseCount,i===0?1:0);if(i===0)assert.ok(result.pausedSeconds>=1);
        assert.equal(result.effort,i===0?3:null);
        assert.deepEqual(result.reviewChecks,condition==='review'?[i===0,false,false]:null);
        const set=packet.sets.find(s=>s.artifactId===result.artifactId);assert.deepEqual(set.cards,result.cards);assert.equal(set.scenario.id,result.scenarioId);assert.ok(csv.includes(result.artifactId));
      }
      function inspect(value){if(value&&typeof value==='object')for(const[k,v]of Object.entries(value)){assert.ok(!['condition','sessionId','position','reviewChecks','activeSeconds','starters','checks','effort','note'].includes(k),`leaked ${k}`);inspect(v);}}
      inspect(packet);assert.equal(csv.trim().split('\n').length,3);
      assert.equal(await page.locator('#summary ul').first().locator('li').first().textContent(),'Look <here> & say “café”');
      assert.equal(await page.locator('#summary here').count(),0);
      assert.equal(await page.evaluate(()=>localStorage.length+sessionStorage.length),0);
      assert.deepEqual(remote,[]);assert.deepEqual(errors,[]);
      if(condition==='review'&&order==='garden,art'){
        await fs.writeFile(path.join(root,'examples/example-session.json'),JSON.stringify(raw,null,2));
        await fs.writeFile(path.join(root,'examples/example-rating-packet.json'),JSON.stringify(packet,null,2));
        await page.screenshot({path:path.join(root,'qa/completed-desktop.png'),fullPage:true});
      }
      await page.click('#restart');assert.equal(await page.locator('#setup').isVisible(),true);
      await context.close();
    });
  }
  await t.test('Mobile, keyboard access, empty set validation and direct file opening',async()=>{
    const context=await browser.newContext({viewport:{width:390,height:844}});const page=await context.newPage();
    await page.goto(base);await page.keyboard.press('Tab');assert.equal(await page.locator('.skip').evaluate(e=>e===document.activeElement),true);
    await page.screenshot({path:path.join(root,'qa/setup-mobile.png'),fullPage:true});
    await page.check('[name=condition][value=review]');await page.click('#start');
    assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));
    await page.screenshot({path:path.join(root,'qa/editor-review-mobile.png'),fullPage:true});
    for(let i=0;i<6;i++)await page.locator('#cards .remove').first().click();
    await page.click('#finish');assert.match(await page.locator('#error').textContent(),/at least one card/);
    await context.close();
    const local=await browser.newPage();await local.goto('file://'+path.join(root,'index.html'));await local.click('#start');assert.equal(await local.locator('#cards input').count(),6);await local.close();
  });
  await t.test('Proposal renders and prints',async()=>{
    const page=await browser.newPage();await page.goto(base+'/docs/mentor-brief.html');assert.match(await page.locator('h1').textContent(),/personalization review/);
    await page.evaluate(()=>document.querySelectorAll('a[href]').forEach(a=>{if(!a.getAttribute('href').startsWith('https://'))a.replaceWith(document.createTextNode(a.textContent));}));
    await page.pdf({path:path.join(root,'docs/mentor-brief.pdf'),format:'A4',printBackground:true,preferCSSPageSize:true});await page.close();
  });
});
